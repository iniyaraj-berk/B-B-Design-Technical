import { useState, useEffect, useRef } from 'react'

// ─── Types ────────────────────────────────────────────────────────────────────

type Screen =
  | 'homepage'
  // Flow 1: Get a Verified Credential
  | 'verify-employment'
  | 'authorize-verification'
  | 'credential-issued'
  | 'credential-wallet'
  // Flow 2: Submit a Tip
  | 'submit-tip'
  | 'choose-credential'
  | 'credential-proof-review'
  | 'submission-success'
  | 'journalist-view'

interface Credential {
  id: string
  organization: string
  year: string
  status: 'valid' | 'revoked'
  issuedAt: string
}

interface TipData {
  organization: string
  year: string
  what: string
  context: string
  files: string[]
}

// ─── Initial State ────────────────────────────────────────────────────────────

const SEED_CREDENTIALS: Credential[] = [
  {
    id: 'FH-2024-STR-3821',
    organization: 'Stripe',
    year: '2024',
    status: 'valid',
    issuedAt: 'March 12, 2025',
  },
  {
    id: 'FH-2023-GGL-9104',
    organization: 'Google',
    year: '2023',
    status: 'valid',
    issuedAt: 'November 8, 2024',
  },
]

const DEFAULT_TIP: TipData = {
  organization: '',
  year: '2025',
  what: '',
  context: '',
  files: [],
}

function makeCredentialId(org: string, year: string): string {
  const prefix = org.trim().slice(0, 3).toUpperCase().replace(/[^A-Z]/g, 'X')
  const num = Math.floor(Math.random() * 9000 + 1000)
  return `FH-${year}-${prefix}-${num}`
}

function makeSubmissionId(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  const seg = (n: number) => Array.from({ length: n }, () => chars[Math.floor(Math.random() * chars.length)]).join('')
  return `SUB-${seg(4)}-${seg(4)}-${seg(4)}`
}

// ─── Design Tokens (CSS Variables) ───────────────────────────────────────────
// Applied via index.css:
//   --maroon: #681B2B
//   --maroon-dark: #4f1421
//   --maroon-tint: #F5EAEC
//   --charcoal: #252525
//   --grey-mid: #6B6B6B
//   --grey-light: #D9D9D9
//   --grey-faint: #F0F0EE
//   --bg: #F7F7F5
//   --white: #FFFFFF
//   --border: #D9D9D9

// ─── Icons ────────────────────────────────────────────────────────────────────

const I = {
  Check: ({ s = 16, c = 'currentColor' }: { s?: number; c?: string }) => (
    <svg width={s} height={s} viewBox="0 0 16 16" fill="none">
      <path d="M3 8.5l3.5 3.5 6.5-7.5" stroke={c} strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  CheckCircle: ({ s = 18 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 18 18" fill="none">
      <circle cx="9" cy="9" r="8" stroke="currentColor" strokeWidth="1.4" />
      <path d="M5.5 9l2.5 2.5 4.5-5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  Shield: ({ s = 18 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 18 18" fill="none">
      <path d="M9 2L3 5v4.5c0 3.6 2.7 6.3 6 7 3.3-.7 6-3.4 6-7V5L9 2z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
      <path d="M6.5 9l2 2 3.5-3.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  Lock: ({ s = 15 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 15 15" fill="none">
      <rect x="2.5" y="6.5" width="10" height="7.5" rx="1.5" stroke="currentColor" strokeWidth="1.25" />
      <path d="M4.5 6.5V4.5a3 3 0 0 1 6 0v2" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" />
      <circle cx="7.5" cy="10.25" r="1" fill="currentColor" />
    </svg>
  ),
  EyeOff: ({ s = 15 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 15 15" fill="none">
      <path d="M2 2l11 11M6 6.1a2 2 0 0 0 2.9 2.9M3.7 3.73C2.38 4.7 1.22 6.27.5 7.5c1.2 2 3.8 4.7 7 4.7 1.2 0 2.3-.4 3.25-1M6.6 2.86C6.9 2.8 7.2 2.75 7.5 2.75c3.2 0 5.8 2.7 7 4.7a14 14 0 0 1-1.45 2.1" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" />
    </svg>
  ),
  Arrow: ({ s = 13 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 13 13" fill="none">
      <path d="M2.5 6.5h8M8 3.5l3 3-3 3" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  Clip: ({ s = 14 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 14 14" fill="none">
      <path d="M11.5 6L5.5 12a3 3 0 0 1-4.2-4.3L6.8 2a2 2 0 0 1 2.8 2.8L4.1 10.4a1 1 0 0 1-1.4-1.4l5.7-5.7" stroke="currentColor" strokeWidth="1.25" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  Wallet: ({ s = 16 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 16 16" fill="none">
      <rect x="1" y="3" width="14" height="10" rx="2" stroke="currentColor" strokeWidth="1.3" />
      <path d="M1 6h14" stroke="currentColor" strokeWidth="1.3" />
      <circle cx="12" cy="9.5" r="1" fill="currentColor" />
    </svg>
  ),
  User: ({ s = 14 }: { s?: number }) => (
    <svg width={s} height={s} viewBox="0 0 14 14" fill="none">
      <circle cx="7" cy="4.5" r="2.5" stroke="currentColor" strokeWidth="1.3" />
      <path d="M1.5 13c0-3 2.5-5 5.5-5s5.5 2 5.5 5" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  ),
}

// ─── Shared Layout Components ─────────────────────────────────────────────────

const S: { [k: string]: React.CSSProperties } = {
  input: {
    width: '100%',
    border: '1px solid var(--grey-light)',
    borderRadius: 4,
    padding: '10px 12px',
    fontSize: 14,
    color: 'var(--charcoal)',
    background: 'var(--white)',
    boxSizing: 'border-box',
    outline: 'none',
  },
}

function PageWrap({ children, narrow }: { children: React.ReactNode; narrow?: boolean }) {
  return (
    <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 48px' }}>
      <div style={{ maxWidth: narrow ? 560 : 640, margin: '0 auto', paddingTop: 60, paddingBottom: 80 }}>
        {children}
      </div>
    </div>
  )
}

function StepDots({ current, total }: { current: number; total: number }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 32 }}>
      {Array.from({ length: total }, (_, i) => (
        <div key={i} style={{
          height: 3, width: i === current - 1 ? 28 : 12,
          borderRadius: 2, background: i < current ? 'var(--maroon)' : 'var(--grey-light)',
          transition: 'all 0.25s',
        }} />
      ))}
      <span style={{ fontSize: 12, color: 'var(--grey-mid)', marginLeft: 6 }}>{current} of {total}</span>
    </div>
  )
}

function PageTitle({ eyebrow, title, body }: { eyebrow?: string; title: string; body?: string }) {
  return (
    <div style={{ marginBottom: 32 }}>
      {eyebrow && (
        <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--maroon)', marginBottom: 10 }}>
          {eyebrow}
        </p>
      )}
      <h1 style={{ fontFamily: 'Playfair Display, Georgia, serif', fontSize: 38, fontWeight: 600, color: 'var(--charcoal)', lineHeight: 1.15, letterSpacing: '-0.02em', marginBottom: body ? 12 : 0 }}>
        {title}
      </h1>
      {body && <p style={{ fontSize: 15, color: 'var(--grey-mid)', lineHeight: 1.7, maxWidth: 480 }}>{body}</p>}
    </div>
  )
}

function Card({ children, style, onClick }: { children: React.ReactNode; style?: React.CSSProperties; onClick?: () => void }) {
  return (
    <div
      onClick={onClick}
      style={{
        background: 'var(--white)', border: '1px solid var(--grey-light)',
        borderRadius: 6, ...style, cursor: onClick ? 'pointer' : undefined,
      }}
    >
      {children}
    </div>
  )
}

function BtnPrimary({ children, onClick, disabled, full }: { children: React.ReactNode; onClick?: () => void; disabled?: boolean; full?: boolean }) {
  const [hov, setHov] = useState(false)
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8,
        width: full ? '100%' : undefined, padding: '12px 24px',
        background: disabled ? 'var(--grey-light)' : hov ? 'var(--maroon-dark)' : 'var(--maroon)',
        color: disabled ? 'var(--grey-mid)' : 'white',
        border: 'none', borderRadius: 4, fontSize: 14, fontWeight: 500,
        cursor: disabled ? 'not-allowed' : 'pointer', transition: 'background 0.15s',
      }}
    >
      {children}
    </button>
  )
}

function BtnGhost({ children, onClick }: { children: React.ReactNode; onClick?: () => void }) {
  const [hov, setHov] = useState(false)
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHov(true)}
      onMouseLeave={() => setHov(false)}
      style={{
        display: 'inline-flex', alignItems: 'center', gap: 6, padding: '12px 22px',
        background: 'transparent', color: 'var(--charcoal)',
        border: `1px solid ${hov ? 'var(--charcoal)' : 'var(--grey-light)'}`,
        borderRadius: 4, fontSize: 14, fontWeight: 500, cursor: 'pointer', transition: 'border-color 0.15s',
      }}
    >
      {children}
    </button>
  )
}

function FormRow({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <label style={{ fontSize: 13, fontWeight: 500, color: 'var(--charcoal)' }}>{label}</label>
      {hint && <p style={{ fontSize: 12, color: 'var(--grey-mid)', marginTop: -2, lineHeight: 1.5 }}>{hint}</p>}
      {children}
    </div>
  )
}

function PrivacyNote({ text }: { text: string }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px', background: 'var(--maroon-tint)', border: '1px solid rgba(104,27,43,0.18)', borderRadius: 4, fontSize: 13, fontWeight: 500, color: 'var(--charcoal)' }}>
      <span style={{ color: 'var(--maroon)', flexShrink: 0 }}><I.EyeOff /></span>
      {text}
    </div>
  )
}

function StatusBadge({ status }: { status: 'valid' | 'revoked' }) {
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5,
      padding: '3px 9px', borderRadius: 100, fontSize: 11, fontWeight: 600,
      background: status === 'valid' ? '#EAF5EE' : '#FEF2F2',
      color: status === 'valid' ? '#1B6B38' : '#9B1C1C',
      border: `1px solid ${status === 'valid' ? '#A7D9B4' : '#FECACA'}`,
    }}>
      <div style={{ width: 5, height: 5, borderRadius: '50%', background: status === 'valid' ? '#1B6B38' : '#9B1C1C' }} />
      {status === 'valid' ? 'Valid' : 'Revoked'}
    </span>
  )
}

// ─── Credential Card Visual ───────────────────────────────────────────────────

function CredentialCard({ cred, compact, selected, onClick }: {
  cred: Credential
  compact?: boolean
  selected?: boolean
  onClick?: () => void
}) {
  const [hov, setHov] = useState(false)
  const isInteractive = !!onClick
  return (
    <div
      onClick={onClick}
      onMouseEnter={() => isInteractive && setHov(true)}
      onMouseLeave={() => isInteractive && setHov(false)}
      style={{
        border: selected ? '2px solid var(--maroon)' : `1.5px solid ${hov ? 'var(--maroon)' : 'var(--grey-light)'}`,
        borderRadius: 8, overflow: 'hidden', cursor: isInteractive ? 'pointer' : 'default',
        boxShadow: selected ? '0 0 0 3px rgba(104,27,43,0.08)' : hov ? '0 2px 8px rgba(104,27,43,0.07)' : 'none',
        transition: 'all 0.15s',
        background: 'var(--white)',
      }}
    >
      {/* Header bar */}
      <div style={{ background: 'var(--maroon)', padding: compact ? '8px 16px' : '11px 20px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 7 }}>
          <span style={{ color: 'white' }}><I.Check s={compact ? 12 : 14} c="white" /></span>
          <span style={{ color: 'white', fontFamily: 'Playfair Display, serif', fontSize: compact ? 11 : 12, fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase' }}>
            Firsthand Verified
          </span>
        </div>
        <span style={{ color: 'rgba(255,255,255,0.55)', fontSize: 10, letterSpacing: '0.04em' }}>
          VERIFIED EMPLOYMENT CREDENTIAL
        </span>
      </div>
      {/* Body */}
      <div style={{ padding: compact ? '14px 16px' : '20px', background: 'var(--maroon-tint)' }}>
        <p style={{ fontFamily: 'Playfair Display, serif', fontSize: compact ? 17 : 22, fontWeight: 600, color: 'var(--charcoal)', letterSpacing: '-0.01em', marginBottom: 3 }}>
          {cred.organization}
        </p>
        <p style={{ fontSize: 12, color: 'var(--grey-mid)', marginBottom: compact ? 10 : 16 }}>
          Employment activity verified · {cred.year}
        </p>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
          <StatusBadge status={cred.status} />
          {!compact && (
            <div style={{ display: 'flex', gap: 16 }}>
              <div>
                <p style={{ fontSize: 10, color: 'var(--grey-mid)', marginBottom: 2 }}>Issued by</p>
                <p style={{ fontSize: 12, fontWeight: 500, color: 'var(--charcoal)' }}>Firsthand</p>
              </div>
              <div>
                <p style={{ fontSize: 10, color: 'var(--grey-mid)', marginBottom: 2 }}>Credential ID</p>
                <p style={{ fontSize: 11, fontFamily: 'monospace', color: 'var(--charcoal)', letterSpacing: '0.04em' }}>{cred.id}</p>
              </div>
            </div>
          )}
          {compact && (
            <span style={{ fontSize: 11, fontFamily: 'monospace', color: 'var(--grey-mid)' }}>{cred.id}</span>
          )}
        </div>
        {selected && (
          <div style={{ marginTop: 12, display: 'flex', alignItems: 'center', gap: 6, color: 'var(--maroon)', fontSize: 12, fontWeight: 600 }}>
            <I.Check s={12} c="var(--maroon)" /> Selected
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Nav ──────────────────────────────────────────────────────────────────────

function Nav({ screen, credentials, onNavigate }: { screen: Screen; credentials: Credential[]; onNavigate: (s: Screen) => void }) {
  const isJournalist = screen === 'journalist-view'
  return (
    <div style={{ position: 'sticky', top: 0, zIndex: 100, background: 'rgba(255,255,255,0.97)', borderBottom: '1px solid var(--grey-light)', backdropFilter: 'blur(8px)' }}>
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 48px', height: 58, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <button onClick={() => onNavigate('homepage')} style={{ fontFamily: 'Playfair Display, serif', fontSize: 19, fontWeight: 600, color: 'var(--charcoal)', background: 'none', border: 'none', cursor: 'pointer', letterSpacing: '-0.02em' }}>
          Firsthand
        </button>
        {isJournalist ? (
          <span style={{ fontSize: 12, fontWeight: 600, color: 'var(--grey-mid)', letterSpacing: '0.06em', textTransform: 'uppercase', background: 'var(--grey-faint)', border: '1px solid var(--grey-light)', padding: '4px 12px', borderRadius: 100 }}>
            Journalist View
          </span>
        ) : (
          <div style={{ display: 'flex', alignItems: 'center', gap: 28 }}>
            {[
              { label: 'How it works', s: undefined as Screen | undefined },
              { label: 'For Journalists', s: undefined as Screen | undefined },
            ].map(({ label }) => (
              <button key={label} style={{ fontSize: 13, color: 'var(--grey-mid)', background: 'none', border: 'none', cursor: 'pointer' }}>
                {label}
              </button>
            ))}
            <button
              onClick={() => onNavigate('credential-wallet')}
              style={{
                display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: 'var(--charcoal)',
                background: 'none', border: '1px solid var(--grey-light)', borderRadius: 4, padding: '5px 12px', cursor: 'pointer',
              }}
            >
              <I.Wallet />
              Credential Wallet
              {credentials.length > 0 && (
                <span style={{ background: 'var(--maroon)', color: 'white', borderRadius: 100, padding: '0 5px', fontSize: 10, fontWeight: 700, lineHeight: '16px' }}>
                  {credentials.length}
                </span>
              )}
            </button>
            <button style={{ fontSize: 13, color: 'var(--charcoal)', background: 'none', border: '1px solid var(--grey-light)', borderRadius: 4, padding: '5px 12px', cursor: 'pointer' }}>
              Sign in
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
// FLOW 1 SCREENS
// ═══════════════════════════════════════════════════════════════════════════════

// ─── Screen 1: Homepage ───────────────────────────────────────────────────────

function Homepage({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  return (
    <div>
      {/* Hero */}
      <div style={{ background: 'var(--white)', borderBottom: '1px solid var(--grey-light)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: '96px 48px 80px' }}>
          <div style={{ maxWidth: 660 }}>
            <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--maroon)', marginBottom: 16 }}>
              Privacy-protected source verification
            </p>
            <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: 64, fontWeight: 600, lineHeight: 1.08, letterSpacing: '-0.03em', color: 'var(--charcoal)', marginBottom: 22 }}>
              Share what you know.<br />
              <span style={{ color: 'var(--maroon)', fontStyle: 'italic' }}>Without sharing</span><br />
              who you are.
            </h1>
            <p style={{ fontSize: 17, color: 'var(--grey-mid)', lineHeight: 1.7, marginBottom: 40, maxWidth: 480, fontWeight: 300 }}>
              Firsthand helps anonymous sources prove their connection to a story without revealing their identity. Firsthand verifies your connection — not the truth of your claim.
            </p>

            {/* TWO PRIMARY ACTIONS */}
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, maxWidth: 520 }}>
              <button
                onClick={() => onNavigate('verify-employment')}
                style={{
                  display: 'flex', flexDirection: 'column', alignItems: 'flex-start', textAlign: 'left',
                  padding: '20px', background: 'var(--maroon)', border: 'none', borderRadius: 6,
                  cursor: 'pointer', transition: 'background 0.15s',
                }}
                onMouseEnter={e => (e.currentTarget.style.background = 'var(--maroon-dark)')}
                onMouseLeave={e => (e.currentTarget.style.background = 'var(--maroon)')}
              >
                <div style={{ marginBottom: 12, color: 'rgba(255,255,255,0.8)' }}><I.Shield /></div>
                <p style={{ fontSize: 15, fontWeight: 600, color: 'white', marginBottom: 4 }}>Get a Verified Credential</p>
                <p style={{ fontSize: 12, color: 'rgba(255,255,255,0.65)', lineHeight: 1.5 }}>
                  Prove your employment connection before submitting a tip.
                </p>
              </button>
              <button
                onClick={() => onNavigate('submit-tip')}
                style={{
                  display: 'flex', flexDirection: 'column', alignItems: 'flex-start', textAlign: 'left',
                  padding: '20px', background: 'var(--white)', border: '1.5px solid var(--grey-light)', borderRadius: 6,
                  cursor: 'pointer', transition: 'border-color 0.15s',
                }}
                onMouseEnter={e => (e.currentTarget.style.borderColor = 'var(--charcoal)')}
                onMouseLeave={e => (e.currentTarget.style.borderColor = 'var(--grey-light)')}
              >
                <div style={{ marginBottom: 12, color: 'var(--maroon)' }}><I.Clip /></div>
                <p style={{ fontSize: 15, fontWeight: 600, color: 'var(--charcoal)', marginBottom: 4 }}>Submit a Tip</p>
                <p style={{ fontSize: 12, color: 'var(--grey-mid)', lineHeight: 1.5 }}>
                  Already have a credential? Attach it as proof when you submit.
                </p>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* How it works */}
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '72px 48px' }}>
        <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.08em', textTransform: 'uppercase', color: 'var(--grey-mid)', marginBottom: 40 }}>
          How it works
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 1, background: 'var(--grey-light)' }}>
          {[
            {
              n: '01',
              icon: <I.Shield />,
              title: 'Verify your connection',
              body: 'Firsthand checks authoritative employment records privately. Your underlying documents are never shown to journalists.',
            },
            {
              n: '02',
              icon: <I.CheckCircle />,
              title: 'Receive a reusable credential',
              body: 'You receive a Verified Employment Credential tied permanently to you. It cannot be transferred to another person.',
            },
            {
              n: '03',
              icon: <I.EyeOff />,
              title: 'Submit anonymously',
              body: 'Attach your credential to any tip. Journalists see your verified employment standing, never your identity.',
            },
          ].map(item => (
            <div key={item.n} style={{ background: 'var(--white)', padding: '36px 32px' }}>
              <p style={{ fontFamily: 'Playfair Display, serif', fontSize: 32, color: 'var(--grey-light)', fontWeight: 400, marginBottom: 18, lineHeight: 1 }}>{item.n}</p>
              <div style={{ color: 'var(--maroon)', marginBottom: 14 }}>{item.icon}</div>
              <h3 style={{ fontFamily: 'Playfair Display, serif', fontSize: 18, fontWeight: 600, color: 'var(--charcoal)', marginBottom: 10, lineHeight: 1.3 }}>{item.title}</h3>
              <p style={{ fontSize: 14, color: 'var(--grey-mid)', lineHeight: 1.7 }}>{item.body}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Dark footer strip */}
      <div style={{ background: 'var(--charcoal)', padding: '56px 48px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <h2 style={{ fontFamily: 'Playfair Display, serif', fontSize: 28, fontWeight: 600, color: 'white', letterSpacing: '-0.02em', marginBottom: 8 }}>
              Ready to get started?
            </h2>
            <p style={{ fontSize: 14, color: 'rgba(255,255,255,0.5)', fontWeight: 300 }}>
              Obtain a credential first, then submit a tip with verified proof of your connection.
            </p>
          </div>
          <div style={{ display: 'flex', gap: 12 }}>
            <button onClick={() => onNavigate('verify-employment')} style={{ padding: '12px 22px', background: 'var(--maroon)', color: 'white', border: 'none', borderRadius: 4, fontSize: 13, fontWeight: 500, cursor: 'pointer' }}>
              Get a Verified Credential
            </button>
            <button onClick={() => onNavigate('submit-tip')} style={{ padding: '12px 22px', background: 'transparent', color: 'rgba(255,255,255,0.7)', border: '1px solid rgba(255,255,255,0.2)', borderRadius: 4, fontSize: 13, fontWeight: 500, cursor: 'pointer' }}>
              Submit a Tip
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

// ─── Screen 2: Verify Employment ──────────────────────────────────────────────

function VerifyEmployment({
  verifyOrg, setVerifyOrg,
  verifyYear, setVerifyYear,
  onNavigate,
}: {
  verifyOrg: string; setVerifyOrg: (v: string) => void
  verifyYear: string; setVerifyYear: (v: string) => void
  onNavigate: (s: Screen) => void
}) {
  const canContinue = verifyOrg.trim().length > 0

  return (
    <PageWrap narrow>
      <StepDots current={1} total={4} />
      <PageTitle
        eyebrow="Get a Verified Credential"
        title="Verify your employment connection"
        body="Firsthand checks authoritative employer-reported records to privately verify your connection to an organization. Your sensitive documents are never shown to journalists."
      />

      <div style={{ display: 'flex', flexDirection: 'column', gap: 18, marginBottom: 28 }}>
        <FormRow label="Organization" hint="The organization where you worked or were employed">
          <input
            style={S.input}
            placeholder="e.g. Acme Technologies"
            value={verifyOrg}
            onChange={e => setVerifyOrg(e.target.value)}
          />
        </FormRow>
        <FormRow label="Employment year or verified period" hint="The year or period of employment you want to verify">
          <select style={S.input} value={verifyYear} onChange={e => setVerifyYear(e.target.value)}>
            {['2025', '2024', '2023', '2022', '2021', '2020', '2019'].map(y => <option key={y} value={y}>{y}</option>)}
          </select>
        </FormRow>
      </div>

      <Card style={{ padding: '20px', marginBottom: 28 }}>
        <p style={{ fontSize: 12, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--grey-mid)', marginBottom: 14 }}>What verification checks</p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          {[
            { check: true, text: `Your connection to ${verifyOrg || 'the organization'}` },
            { check: true, text: `Employment activity during ${verifyYear}` },
            { check: false, text: 'Your name or personal identity — never shared with journalists' },
            { check: false, text: 'Tax, income, or W-2 documents — never accessible to journalists' },
          ].map((item, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
              <div style={{ width: 18, height: 18, borderRadius: '50%', flexShrink: 0, marginTop: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', background: item.check ? 'rgba(104,27,43,0.08)' : 'var(--grey-faint)', border: `1px solid ${item.check ? 'rgba(104,27,43,0.18)' : 'var(--grey-light)'}` }}>
                {item.check
                  ? <I.Check s={10} c="var(--maroon)" />
                  : <I.Lock s={10} />
                }
              </div>
              <span style={{ fontSize: 13, color: 'var(--charcoal)', lineHeight: 1.5 }}>{item.text}</span>
            </div>
          ))}
        </div>
      </Card>

      <PrivacyNote text="The resulting credential only proves your organization and verified employment period." />

      <div style={{ marginTop: 24 }}>
        <BtnPrimary onClick={() => onNavigate('authorize-verification')} disabled={!canContinue} full>
          Continue to verification <I.Arrow />
        </BtnPrimary>
        {!canContinue && <p style={{ fontSize: 12, color: 'var(--grey-mid)', marginTop: 8, textAlign: 'center' }}>Enter an organization to continue.</p>}
      </div>
    </PageWrap>
  )
}

// ─── Screen 3: Authorize Verification ─────────────────────────────────────────

function AuthorizeVerification({
  verifyOrg, verifyYear,
  onCredentialIssued,
  onNavigate,
}: {
  verifyOrg: string; verifyYear: string
  onCredentialIssued: (c: Credential) => void
  onNavigate: (s: Screen) => void
}) {
  const [agreed, setAgreed] = useState(false)
  const [phase, setPhase] = useState<'idle' | 'loading' | 'done'>('idle')
  const [progress, setProgress] = useState(0)
  const [statusLine, setStatusLine] = useState('')

  const steps = [
    'Connecting to employer-reported records…',
    `Locating records for ${verifyOrg}…`,
    `Verifying employment activity during ${verifyYear}…`,
    'Confirming identity match…',
    'Issuing Verified Employment Credential…',
  ]

  const handleAuthorize = () => {
    if (!agreed) return
    setPhase('loading')
    let p = 0, si = 0
    setStatusLine(steps[0])
    const iv = setInterval(() => {
      p += 3 + Math.random() * 7
      const ni = Math.min(Math.floor((p / 100) * steps.length), steps.length - 1)
      if (ni !== si) { si = ni; setStatusLine(steps[ni]) }
      if (p >= 100) {
        p = 100; clearInterval(iv)
        const cred: Credential = {
          id: makeCredentialId(verifyOrg, verifyYear),
          organization: verifyOrg, year: verifyYear,
          status: 'valid',
          issuedAt: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
        }
        onCredentialIssued(cred)
        setPhase('done')
        setTimeout(() => onNavigate('credential-issued'), 700)
      }
      setProgress(Math.min(p, 100))
    }, 220)
  }

  return (
    <PageWrap narrow>
      <StepDots current={2} total={4} />
      <PageTitle
        eyebrow="Authorization required"
        title="Authorize employment verification"
        body="Review what Firsthand will verify and confirm your authorization before proceeding."
      />

      {/* Requesting block */}
      <Card style={{ marginBottom: 16, overflow: 'hidden' }}>
        <div style={{ padding: '12px 18px', borderBottom: '1px solid var(--grey-light)', background: 'var(--grey-faint)' }}>
          <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--grey-mid)' }}>Firsthand is requesting access to verify</p>
        </div>
        {[
          { label: `Your connection to ${verifyOrg}`, note: 'Employer-reported records accessed privately', check: true },
          { label: `Employment activity during ${verifyYear}`, note: 'Confirmed and included in credential', check: true },
          { label: 'Your identity', note: 'Used for matching only — never shown to journalists', check: false },
        ].map((item, i, arr) => (
          <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 14, padding: '15px 18px', borderBottom: i < arr.length - 1 ? '1px solid var(--grey-light)' : 'none' }}>
            <div style={{ width: 20, height: 20, borderRadius: '50%', flexShrink: 0, marginTop: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', background: item.check ? 'rgba(104,27,43,0.08)' : 'var(--grey-faint)', border: `1px solid ${item.check ? 'rgba(104,27,43,0.18)' : 'var(--grey-light)'}` }}>
              {item.check ? <I.Check s={11} c="var(--maroon)" /> : <I.Lock s={11} />}
            </div>
            <div>
              <p style={{ fontSize: 14, fontWeight: 500, color: 'var(--charcoal)' }}>{item.label}</p>
              <p style={{ fontSize: 12, color: 'var(--grey-mid)', marginTop: 2 }}>{item.note}</p>
            </div>
          </div>
        ))}
      </Card>

      {/* What is stored vs not stored */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 24 }}>
        <Card style={{ padding: 18 }}>
          <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase', color: 'var(--maroon)', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 5 }}>
            <I.Lock s={12} /> Not stored or shared
          </p>
          {['Your full identity', 'Tax / W-2 documents', 'Income information', 'Social Security number'].map(t => (
            <div key={t} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 9 }}>
              <I.Lock s={11} />
              <span style={{ fontSize: 12, color: 'var(--charcoal)' }}>{t}</span>
            </div>
          ))}
        </Card>
        <Card style={{ padding: 18 }}>
          <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase', color: 'var(--maroon)', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 5 }}>
            <I.Check s={12} c="var(--maroon)" /> Issued in credential
          </p>
          {[`Connection to ${verifyOrg}`, `Employment activity · ${verifyYear}`, 'Credential status', 'Issuing organization'].map(t => (
            <div key={t} style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginBottom: 9 }}>
              <I.Check s={11} c="var(--maroon)" />
              <span style={{ fontSize: 12, color: 'var(--charcoal)' }}>{t}</span>
            </div>
          ))}
        </Card>
      </div>

      {/* Authorization checkbox */}
      <div
        onClick={() => phase === 'idle' && setAgreed(a => !a)}
        style={{ display: 'flex', alignItems: 'flex-start', gap: 12, padding: '14px 16px', background: agreed ? 'var(--maroon-tint)' : 'var(--white)', border: `1px solid ${agreed ? 'rgba(104,27,43,0.25)' : 'var(--grey-light)'}`, borderRadius: 4, cursor: 'pointer', marginBottom: 20, transition: 'all 0.15s' }}
      >
        <div style={{ width: 18, height: 18, borderRadius: 3, border: `1.5px solid ${agreed ? 'var(--maroon)' : 'var(--grey-light)'}`, background: agreed ? 'var(--maroon)' : 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 1 }}>
          {agreed && <I.Check s={11} c="white" />}
        </div>
        <p style={{ fontSize: 13, color: 'var(--charcoal)', lineHeight: 1.6 }}>
          I authorize Firsthand to access employer-reported records to verify my employment connection to <strong>{verifyOrg}</strong> during <strong>{verifyYear}</strong>. I understand my underlying documents and identity will not be shown to journalists.
        </p>
      </div>

      {phase === 'idle' ? (
        <BtnPrimary onClick={handleAuthorize} disabled={!agreed} full>
          Authorize verification
        </BtnPrimary>
      ) : (
        <Card style={{ padding: 22 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <p style={{ fontSize: 13, fontWeight: 500, color: 'var(--charcoal)' }}>
              {phase === 'done' ? 'Verification complete' : statusLine}
            </p>
            <span style={{ fontSize: 12, color: 'var(--grey-mid)', fontVariantNumeric: 'tabular-nums' }}>{Math.round(progress)}%</span>
          </div>
          <div style={{ height: 4, background: 'var(--grey-faint)', borderRadius: 2, overflow: 'hidden' }}>
            <div style={{ height: '100%', borderRadius: 2, width: `${progress}%`, background: phase === 'done' ? '#1B6B38' : 'var(--maroon)', transition: 'width 0.25s ease' }} />
          </div>
          {phase === 'done' && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginTop: 12, color: '#1B6B38', fontSize: 13, fontWeight: 500 }}>
              <I.CheckCircle s={15} /> Records verified. Issuing credential…
            </div>
          )}
        </Card>
      )}
    </PageWrap>
  )
}

// ─── Screen 4: Credential Issued ──────────────────────────────────────────────

function CredentialIssued({
  latestCredential,
  onNavigate,
}: {
  latestCredential: Credential | null
  onNavigate: (s: Screen) => void
}) {
  const [vis, setVis] = useState(false)
  useEffect(() => { const t = setTimeout(() => setVis(true), 60); return () => clearTimeout(t) }, [])

  if (!latestCredential) return null

  return (
    <PageWrap narrow>
      <div style={{ opacity: vis ? 1 : 0, transform: vis ? 'translateY(0)' : 'translateY(10px)', transition: 'all 0.45s ease' }}>
        <StepDots current={3} total={4} />

        <div style={{ marginBottom: 8 }}>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 10px', borderRadius: 100, fontSize: 11, fontWeight: 600, background: '#EAF5EE', color: '#1B6B38', border: '1px solid #A7D9B4', letterSpacing: '0.04em', textTransform: 'uppercase' }}>
            <I.Check s={11} c="#1B6B38" /> Verification successful
          </span>
        </div>

        <PageTitle title="Your connection is verified." body={`Firsthand has issued a Verified Employment Credential confirming your connection to ${latestCredential.organization}.`} />

        {/* The credential */}
        <div style={{ opacity: vis ? 1 : 0, transform: vis ? 'scale(1)' : 'scale(0.97)', transition: 'all 0.55s ease 0.15s', marginBottom: 24 }}>
          <CredentialCard cred={latestCredential} />
        </div>

        <Card style={{ padding: 20, marginBottom: 24 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 16 }}>
            {[
              { label: 'Credential ID', value: latestCredential.id, mono: true },
              { label: 'Issued', value: latestCredential.issuedAt },
              { label: 'Status', value: 'Active · Non-transferable', green: true },
            ].map(item => (
              <div key={item.label}>
                <p style={{ fontSize: 11, color: 'var(--grey-mid)', marginBottom: 4 }}>{item.label}</p>
                <p style={{ fontSize: 12, fontWeight: 500, color: item.green ? '#1B6B38' : 'var(--charcoal)', fontFamily: item.mono ? 'monospace' : 'inherit', letterSpacing: item.mono ? '0.04em' : 'inherit' }}>
                  {item.value}
                </p>
              </div>
            ))}
          </div>
        </Card>

        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10, padding: '14px 16px', background: 'var(--grey-faint)', border: '1px solid var(--grey-light)', borderRadius: 4, marginBottom: 28 }}>
          <span style={{ color: 'var(--maroon)', flexShrink: 0, marginTop: 1 }}><I.Lock /></span>
          <p style={{ fontSize: 13, color: 'var(--grey-mid)', lineHeight: 1.65 }}>
            <strong style={{ color: 'var(--charcoal)', fontWeight: 500 }}>This credential is permanently tied to you and cannot be transferred to another person.</strong>{' '}
            Firsthand can now prove your connection to {latestCredential.organization} without revealing your identity or underlying records.
          </p>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <BtnPrimary onClick={() => onNavigate('submit-tip')} full>
            Submit a Tip Using This Credential <I.Arrow />
          </BtnPrimary>
          <BtnGhost onClick={() => onNavigate('credential-wallet')}>
            <I.Wallet /> View Credential Wallet
          </BtnGhost>
        </div>
      </div>
    </PageWrap>
  )
}

// ─── Screen 5: Credential Wallet ──────────────────────────────────────────────

function CredentialWallet({ credentials, onNavigate }: { credentials: Credential[]; onNavigate: (s: Screen) => void }) {
  return (
    <PageWrap>
      <StepDots current={4} total={4} />
      <PageTitle
        eyebrow="Credential Wallet"
        title="Your Verified Employment Credentials"
        body="Your credentials are reusable. Attach any credential as proof when submitting a tip — you choose how to prove your connection."
      />

      <Card style={{ padding: '14px 18px', marginBottom: 24, display: 'flex', alignItems: 'center', gap: 10 }}>
        <span style={{ color: 'var(--maroon)' }}><I.Lock /></span>
        <p style={{ fontSize: 13, color: 'var(--charcoal)', lineHeight: 1.6 }}>
          <strong style={{ fontWeight: 500 }}>Your credentials can be reused</strong> whenever you need to prove relevant employment standing without revealing your identity.
          Each credential is non-transferable and permanently tied to you.
        </p>
      </Card>

      {credentials.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '48px 0', color: 'var(--grey-mid)' }}>
          <p style={{ fontSize: 15, marginBottom: 16 }}>No credentials yet.</p>
          <BtnPrimary onClick={() => onNavigate('verify-employment')}>Get your first credential</BtnPrimary>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 16, marginBottom: 32 }}>
          {credentials.map(cred => (
            <CredentialCard key={cred.id} cred={cred} />
          ))}
        </div>
      )}

      {credentials.length > 0 && (
        <div style={{ display: 'flex', gap: 12 }}>
          <BtnPrimary onClick={() => onNavigate('submit-tip')}>
            Submit a Tip <I.Arrow />
          </BtnPrimary>
          <BtnGhost onClick={() => onNavigate('verify-employment')}>
            Get another credential
          </BtnGhost>
        </div>
      )}
    </PageWrap>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
// FLOW 2 SCREENS
// ═══════════════════════════════════════════════════════════════════════════════

// ─── Screen 6: Submit a Tip ───────────────────────────────────────────────────

function SubmitTip({
  tip, onChange, onNavigate,
}: {
  tip: TipData; onChange: (t: TipData) => void; onNavigate: (s: Screen) => void
}) {
  const fileRef = useRef<HTMLInputElement>(null)
  const [dragOver, setDragOver] = useState(false)

  const addFiles = (list: FileList) => {
    const names = Array.from(list).map(f => f.name).filter(n => !tip.files.includes(n))
    onChange({ ...tip, files: [...tip.files, ...names] })
  }

  const canContinue = tip.organization.trim().length > 0 && tip.what.trim().length > 0

  return (
    <PageWrap>
      <StepDots current={1} total={4} />
      <PageTitle eyebrow="Submit a Tip" title="Submit a confidential tip" body="Describe what happened. Your identity will not be attached to this submission." />

      <PrivacyNote text="Your identity will not be attached to this submission at any point." />

      <div style={{ display: 'flex', flexDirection: 'column', gap: 18, marginTop: 24, marginBottom: 28 }}>
        <FormRow label="Organization" hint="The organization this tip concerns">
          <input style={S.input} placeholder="e.g. Acme Technologies" value={tip.organization} onChange={e => onChange({ ...tip, organization: e.target.value })} />
        </FormRow>
        <FormRow label="When did this happen?" hint="Approximate year or period">
          <select style={S.input} value={tip.year} onChange={e => onChange({ ...tip, year: e.target.value })}>
            {['2025', '2024', '2023', '2022', '2021', '2020'].map(y => <option key={y} value={y}>{y}</option>)}
          </select>
        </FormRow>
        <FormRow label="What happened?" hint="Be as specific as possible — dates, people, decisions, documents involved">
          <textarea
            style={{ ...S.input, minHeight: 160, resize: 'vertical', lineHeight: 1.7 }}
            placeholder="Describe what you witnessed or experienced…"
            value={tip.what}
            onChange={e => onChange({ ...tip, what: e.target.value })}
          />
        </FormRow>
        <FormRow label="Additional context" hint="Optional — background, related events, or other relevant information">
          <textarea
            style={{ ...S.input, minHeight: 80, resize: 'vertical', lineHeight: 1.7 }}
            placeholder="Any additional context that may help a journalist…"
            value={tip.context}
            onChange={e => onChange({ ...tip, context: e.target.value })}
          />
        </FormRow>
        <FormRow label="Supporting evidence" hint="Optional — documents, images, or files">
          <div
            onDragOver={e => { e.preventDefault(); setDragOver(true) }}
            onDragLeave={() => setDragOver(false)}
            onDrop={e => { e.preventDefault(); setDragOver(false); if (e.dataTransfer.files) addFiles(e.dataTransfer.files) }}
            onClick={() => fileRef.current?.click()}
            style={{ border: `1.5px dashed ${dragOver ? 'var(--maroon)' : 'var(--grey-light)'}`, borderRadius: 4, padding: '24px 20px', textAlign: 'center', cursor: 'pointer', background: dragOver ? 'var(--maroon-tint)' : 'var(--white)', transition: 'all 0.15s' }}
          >
            <input ref={fileRef} type="file" multiple style={{ display: 'none' }} onChange={e => { if (e.target.files) addFiles(e.target.files) }} />
            <div style={{ color: 'var(--grey-mid)', margin: '0 auto 8px', width: 'fit-content' }}><I.Clip /></div>
            <p style={{ fontSize: 13, color: 'var(--grey-mid)' }}>Drop files here or <span style={{ color: 'var(--maroon)', textDecoration: 'underline' }}>browse</span></p>
            <p style={{ fontSize: 11, color: 'var(--grey-mid)', marginTop: 4 }}>Any format accepted</p>
          </div>
          {tip.files.length > 0 && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 10 }}>
              {tip.files.map(f => (
                <span key={f} style={{ display: 'inline-flex', alignItems: 'center', gap: 6, padding: '4px 10px', background: 'var(--grey-faint)', border: '1px solid var(--grey-light)', borderRadius: 4, fontSize: 12, color: 'var(--charcoal)' }}>
                  <I.Clip s={11} /> {f}
                  <button onClick={() => onChange({ ...tip, files: tip.files.filter(x => x !== f) })} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--grey-mid)', fontSize: 14, lineHeight: 1, padding: 0, marginLeft: 2 }}>×</button>
                </span>
              ))}
            </div>
          )}
        </FormRow>
      </div>

      <BtnPrimary onClick={() => onNavigate('choose-credential')} disabled={!canContinue} full>
        Continue <I.Arrow />
      </BtnPrimary>
      {!canContinue && <p style={{ fontSize: 12, color: 'var(--grey-mid)', marginTop: 8, textAlign: 'center' }}>Fill in the organization and what happened to continue.</p>}
    </PageWrap>
  )
}

// ─── Screen 7: Choose Existing Credential ─────────────────────────────────────

function ChooseCredential({
  credentials,
  selectedCredentialId,
  setSelectedCredentialId,
  onNavigate,
}: {
  credentials: Credential[]
  selectedCredentialId: string | null
  setSelectedCredentialId: (id: string | null) => void
  onNavigate: (s: Screen) => void
}) {
  // NOTE: Credential-to-tip matching logic is intentionally NOT implemented here.
  // The selectedCredentialId is set when the user clicks a credential.
  // Verification of whether the credential matches the tip (organization, year, status)
  // should be implemented manually in the credential-proof-review screen or here.

  const hasCredentials = credentials.length > 0

  return (
    <PageWrap>
      <StepDots current={2} total={4} />
      <PageTitle
        eyebrow="Choose a credential"
        title="Choose a credential to attach as proof"
        body="Select a credential from your wallet that establishes your connection to this story. This will be shown to the journalist alongside your tip."
      />

      {!hasCredentials ? (
        <div style={{ textAlign: 'center', padding: '32px 0 24px' }}>
          <p style={{ fontSize: 15, color: 'var(--grey-mid)', marginBottom: 20 }}>
            You don't have any credentials yet. Get a Verified Employment Credential first.
          </p>
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center' }}>
            <BtnPrimary onClick={() => onNavigate('verify-employment')}>
              Get a Verified Credential <I.Arrow />
            </BtnPrimary>
          </div>
        </div>
      ) : (
        <>
          <p style={{ fontSize: 13, color: 'var(--grey-mid)', marginBottom: 20 }}>
            Your credential wallet contains <strong style={{ color: 'var(--charcoal)' }}>{credentials.length} credential{credentials.length !== 1 ? 's' : ''}</strong>. Select one to attach as proof.
          </p>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 28 }}>
            {credentials.map(cred => (
              <CredentialCard
                key={cred.id}
                cred={cred}
                selected={selectedCredentialId === cred.id}
                onClick={() => setSelectedCredentialId(selectedCredentialId === cred.id ? null : cred.id)}
              />
            ))}
          </div>

          <div style={{ display: 'flex', gap: 12 }}>
            <BtnPrimary onClick={() => onNavigate('credential-proof-review')} disabled={!selectedCredentialId} full>
              Continue with selected credential <I.Arrow />
            </BtnPrimary>
          </div>
          {!selectedCredentialId && (
            <p style={{ fontSize: 12, color: 'var(--grey-mid)', marginTop: 8, textAlign: 'center' }}>
              Select a credential to continue.
            </p>
          )}
          <div style={{ marginTop: 16, textAlign: 'center' }}>
            <button onClick={() => onNavigate('verify-employment')} style={{ fontSize: 12, color: 'var(--maroon)', background: 'none', border: 'none', cursor: 'pointer', textDecoration: 'underline', textUnderlineOffset: 3 }}>
              Get another credential first
            </button>
          </div>
        </>
      )}
    </PageWrap>
  )
}

// ─── Screen 8: Credential Proof Review ────────────────────────────────────────

function CredentialProofReview({
  tip,
  selectedCredential,
  onNavigate,
}: {
  tip: TipData
  selectedCredential: Credential | null
  onNavigate: (s: Screen) => void
}) {
  // NOTE: Credential verification logic is intentionally left unimplemented.
  // To implement: check whether selectedCredential.organization matches tip.organization,
  // selectedCredential.year matches tip.year, and selectedCredential.status === 'valid'.
  // The placeholder below marks where the verification result should appear.

  if (!selectedCredential) return null

  return (
    <PageWrap>
      <StepDots current={3} total={4} />
      <PageTitle
        eyebrow="Review proof"
        title="Review your credential attachment"
        body="Before submitting, review your tip and the credential you are attaching as proof of your connection."
      />

      {/* Tip summary */}
      <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--grey-mid)', marginBottom: 12 }}>Your tip</p>
      <Card style={{ padding: 20, marginBottom: 20 }}>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 14 }}>
          <div>
            <p style={{ fontSize: 11, color: 'var(--grey-mid)', marginBottom: 4 }}>Organization</p>
            <p style={{ fontSize: 15, fontWeight: 600, color: 'var(--charcoal)', fontFamily: 'Playfair Display, serif' }}>{tip.organization}</p>
          </div>
          <div>
            <p style={{ fontSize: 11, color: 'var(--grey-mid)', marginBottom: 4 }}>Period</p>
            <p style={{ fontSize: 15, fontWeight: 600, color: 'var(--charcoal)', fontFamily: 'Playfair Display, serif' }}>{tip.year}</p>
          </div>
        </div>
        {tip.what && (
          <div>
            <p style={{ fontSize: 11, color: 'var(--grey-mid)', marginBottom: 6 }}>What happened</p>
            <p style={{ fontSize: 13, color: 'var(--charcoal)', lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>{tip.what.slice(0, 200)}{tip.what.length > 200 ? '…' : ''}</p>
          </div>
        )}
      </Card>

      {/* Selected credential */}
      <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--grey-mid)', marginBottom: 12 }}>Attached credential</p>
      <div style={{ marginBottom: 20 }}>
        <CredentialCard cred={selectedCredential} compact />
      </div>

      {/* Verification result placeholder */}
      <div style={{ border: '1.5px dashed var(--grey-light)', borderRadius: 6, padding: '20px 20px', marginBottom: 24 }}>
        <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--grey-mid)', marginBottom: 8 }}>
          Credential verification result
        </p>
        {/* ── PLACEHOLDER: implement credential verification logic here ─────────
            Check:
              1. selectedCredential.organization === tip.organization
              2. selectedCredential.year === tip.year
              3. selectedCredential.status === 'valid'
            Then render the appropriate verified / mismatch / invalid UI.
        ─────────────────────────────────────────────────────────────────────── */}
        <p style={{ fontSize: 13, color: 'var(--grey-mid)', fontStyle: 'italic', lineHeight: 1.6 }}>
          Credential verification result will appear here.
        </p>
      </div>

      <BtnPrimary onClick={() => onNavigate('submission-success')} full>
        Attach proof &amp; continue <I.Arrow />
      </BtnPrimary>
    </PageWrap>
  )
}

// ─── Screen 9: Submission Success ─────────────────────────────────────────────

function SubmissionSuccess({
  tip,
  selectedCredential,
  submissionId,
  onNavigate,
}: {
  tip: TipData
  selectedCredential: Credential | null
  submissionId: string
  onNavigate: (s: Screen) => void
}) {
  const [vis, setVis] = useState(false)
  useEffect(() => { const t = setTimeout(() => setVis(true), 60); return () => clearTimeout(t) }, [])

  return (
    <PageWrap narrow>
      <div style={{ opacity: vis ? 1 : 0, transform: vis ? 'translateY(0)' : 'translateY(10px)', transition: 'all 0.45s ease' }}>
        <div style={{ width: 48, height: 48, borderRadius: '50%', background: '#EAF5EE', border: '1px solid #A7D9B4', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 24 }}>
          <I.Check s={22} c="#1B6B38" />
        </div>

        <StepDots current={4} total={4} />
        <PageTitle title="Your tip was submitted anonymously." body="Your identity was not included at any point in this process." />

        {/* Submission ID */}
        <Card style={{ padding: '14px 18px', marginBottom: 20, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <p style={{ fontSize: 11, color: 'var(--grey-mid)', marginBottom: 4 }}>Submission ID</p>
            <p style={{ fontSize: 12, fontFamily: 'monospace', letterSpacing: '0.06em', color: 'var(--charcoal)', fontWeight: 500 }}>{submissionId}</p>
          </div>
          <span style={{ fontSize: 11, fontWeight: 600, background: 'var(--maroon-tint)', color: 'var(--maroon)', border: '1px solid rgba(104,27,43,0.2)', borderRadius: 100, padding: '3px 10px', letterSpacing: '0.04em', textTransform: 'uppercase' }}>
            Anonymous
          </span>
        </Card>

        {/* Shared / not shared */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 24 }}>
          <Card style={{ padding: 18 }}>
            <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: '#1B6B38', marginBottom: 12 }}>Shared with journalist</p>
            {[
              'Tip content',
              tip.files.length > 0 ? `Evidence (${tip.files.length} file${tip.files.length !== 1 ? 's' : ''})` : null,
              selectedCredential ? `Verified connection to ${selectedCredential.organization}` : null,
              selectedCredential ? `Employment activity · ${selectedCredential.year}` : null,
            ].filter(Boolean).map(item => (
              <div key={item as string} style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginBottom: 9 }}>
                <I.Check s={12} c="#1B6B38" />
                <span style={{ fontSize: 12, color: 'var(--charcoal)', lineHeight: 1.5 }}>{item}</span>
              </div>
            ))}
          </Card>
          <Card style={{ padding: 18 }}>
            <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--grey-mid)', marginBottom: 12 }}>Not shared</p>
            {['Name', 'Tax or employment records', 'Account information', 'Any identifying information'].map(item => (
              <div key={item} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 9 }}>
                <I.Lock s={12} />
                <span style={{ fontSize: 12, color: 'var(--grey-mid)' }}>{item}</span>
              </div>
            ))}
          </Card>
        </div>

        {/* Key explanations */}
        <Card style={{ padding: 20, marginBottom: 28 }}>
          {[
            'The journalist receives the tip and attached evidence.',
            'They can see the employment standing you chose to prove.',
            'They cannot see your identity or underlying verification documents.',
            'Firsthand verifies employment standing — not whether the allegation itself is true.',
          ].map((text, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'flex-start', gap: 10, marginBottom: i < 3 ? 12 : 0 }}>
              <I.Check s={13} c="var(--maroon)" />
              <p style={{ fontSize: 13, color: 'var(--charcoal)', lineHeight: 1.6 }}>{text}</p>
            </div>
          ))}
        </Card>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <BtnPrimary onClick={() => onNavigate('journalist-view')} full>
            View journalist perspective <I.Arrow />
          </BtnPrimary>
          <BtnGhost onClick={() => onNavigate('homepage')}>
            Return to homepage
          </BtnGhost>
        </div>
      </div>
    </PageWrap>
  )
}

// ─── Screen 10: Journalist View ───────────────────────────────────────────────

function JournalistView({
  tip,
  selectedCredential,
  submissionId,
  onNavigate,
}: {
  tip: TipData
  selectedCredential: Credential | null
  submissionId: string
  onNavigate: (s: Screen) => void
}) {
  const [tipOpen, setTipOpen] = useState(true)

  return (
    <div>
      {/* Journalist sub-nav */}
      <div style={{ background: 'var(--white)', borderBottom: '1px solid var(--grey-light)', padding: '10px 48px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', gap: 0 }}>
            {['Inbox', 'Verified Sources', 'Archive'].map((tab, i) => (
              <button key={tab} style={{ fontSize: 13, fontWeight: i === 0 ? 600 : 400, color: i === 0 ? 'var(--charcoal)' : 'var(--grey-mid)', background: 'none', border: 'none', borderBottom: i === 0 ? '2px solid var(--maroon)' : '2px solid transparent', padding: '6px 16px 8px', cursor: 'pointer' }}>
                {tab}{i === 0 ? <span style={{ marginLeft: 6, background: 'var(--maroon)', color: 'white', borderRadius: 100, padding: '0 5px', fontSize: 10, fontWeight: 700, lineHeight: '16px' }}>1</span> : ''}
              </button>
            ))}
          </div>
          <button onClick={() => onNavigate('homepage')} style={{ fontSize: 12, color: 'var(--grey-mid)', background: 'none', border: '1px solid var(--grey-light)', borderRadius: 4, padding: '5px 12px', cursor: 'pointer' }}>
            ← Exit journalist view
          </button>
        </div>
      </div>

      {/* Main layout */}
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '32px 48px 64px', display: 'grid', gridTemplateColumns: '240px 1fr', gap: 28 }}>

        {/* Sidebar */}
        <div>
          <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--grey-mid)', marginBottom: 14 }}>Recent tips</p>
          <div style={{ background: 'var(--white)', border: '1.5px solid var(--maroon)', borderRadius: 6, padding: '14px 16px', cursor: 'pointer' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 7, marginBottom: 5 }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--maroon)', flexShrink: 0 }} />
              <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--charcoal)' }}>{tip.organization || 'Anonymous tip'}</p>
            </div>
            <p style={{ fontSize: 12, color: 'var(--grey-mid)', marginBottom: 7 }}>Anonymous Source</p>
            {selectedCredential && (
              <div style={{ display: 'flex', alignItems: 'center', gap: 5 }}>
                <I.Check s={11} c="var(--maroon)" />
                <span style={{ fontSize: 11, color: 'var(--maroon)', fontWeight: 500 }}>Firsthand Verified</span>
              </div>
            )}
            <p style={{ fontSize: 11, color: 'var(--grey-mid)', marginTop: 8 }}>
              {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
            </p>
          </div>
        </div>

        {/* Main content */}
        <div>
          {/* Header */}
          <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 24 }}>
            <div>
              <h1 style={{ fontFamily: 'Playfair Display, serif', fontSize: 28, fontWeight: 600, color: 'var(--charcoal)', letterSpacing: '-0.02em', marginBottom: 4 }}>
                {tip.organization}
              </h1>
              <p style={{ fontSize: 12, color: 'var(--grey-mid)' }}>
                Received {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })} · Submission {submissionId}
              </p>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ width: 34, height: 34, borderRadius: '50%', background: 'var(--grey-faint)', border: '1px solid var(--grey-light)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <I.User />
              </div>
              <div>
                <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--charcoal)' }}>Anonymous Source</p>
                <p style={{ fontSize: 11, color: 'var(--grey-mid)' }}>Identity protected</p>
              </div>
            </div>
          </div>

          {/* Verification card — the hero */}
          {selectedCredential && (
            <div style={{ border: '1.5px solid var(--maroon)', borderRadius: 8, overflow: 'hidden', marginBottom: 20, boxShadow: '0 2px 16px rgba(104,27,43,0.10)' }}>
              <div style={{ background: 'var(--maroon)', padding: '13px 22px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <I.Check s={15} c="white" />
                  <span style={{ fontFamily: 'Playfair Display, serif', fontSize: 13, fontWeight: 600, color: 'white', letterSpacing: '0.05em', textTransform: 'uppercase' }}>
                    Firsthand Verified
                  </span>
                </div>
                <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.55)', fontFamily: 'monospace' }}>{selectedCredential.id}</span>
              </div>

              <div style={{ padding: '20px 22px', background: 'var(--white)' }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr auto', gap: 20, marginBottom: 20 }}>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                    {[
                      { label: `Connection to ${selectedCredential.organization} verified`, sub: 'Source has employer-reported evidence of a connection to this organization', check: true },
                      { label: `Employment activity verified · ${selectedCredential.year}`, sub: 'Active employment or engagement confirmed during this period', check: true },
                      { label: 'Identity protected', sub: "The source's name and documents are not accessible", check: false },
                    ].map(item => (
                      <div key={item.label} style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
                        <div style={{ width: 20, height: 20, borderRadius: '50%', flexShrink: 0, marginTop: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', background: item.check ? 'rgba(104,27,43,0.08)' : 'var(--grey-faint)', border: `1px solid ${item.check ? 'rgba(104,27,43,0.18)' : 'var(--grey-light)'}` }}>
                          {item.check ? <I.Check s={11} c="var(--maroon)" /> : <I.Lock s={11} />}
                        </div>
                        <div>
                          <p style={{ fontSize: 13, fontWeight: item.check ? 500 : 400, color: item.check ? 'var(--charcoal)' : 'var(--grey-mid)' }}>{item.label}</p>
                          <p style={{ fontSize: 12, color: 'var(--grey-mid)', marginTop: 2 }}>{item.sub}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                  <div style={{ borderLeft: '1px solid var(--grey-light)', paddingLeft: 22, display: 'flex', flexDirection: 'column', gap: 14, justifyContent: 'center' }}>
                    {[
                      { label: 'Status', value: 'Valid', green: true },
                      { label: 'Non-transferable', value: 'Yes' },
                      { label: 'Issued', value: selectedCredential.issuedAt },
                    ].map(item => (
                      <div key={item.label}>
                        <p style={{ fontSize: 11, color: 'var(--grey-mid)', marginBottom: 3 }}>{item.label}</p>
                        <p style={{ fontSize: 12, fontWeight: 600, color: item.green ? '#1B6B38' : 'var(--charcoal)' }}>{item.value}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Important disclaimer */}
                <div style={{ borderTop: '1px solid var(--grey-light)', paddingTop: 14, display: 'flex', gap: 10 }}>
                  <div style={{ width: 18, height: 18, borderRadius: '50%', background: '#FEF3C7', border: '1px solid #FCD34D', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0, marginTop: 1 }}>
                    <span style={{ fontSize: 10, fontWeight: 700, color: '#92400E' }}>!</span>
                  </div>
                  <p style={{ fontSize: 12, color: 'var(--grey-mid)', lineHeight: 1.65 }}>
                    <strong style={{ color: 'var(--charcoal)', fontWeight: 600 }}>Firsthand verifies the source's employment connection — not the truth of the claim.</strong>{' '}
                    All allegations require independent journalistic investigation and corroboration before publication.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* What Firsthand verifies vs. does not verify */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 20 }}>
            <Card style={{ padding: 18 }}>
              <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: '#1B6B38', marginBottom: 10 }}>What Firsthand verifies</p>
              <p style={{ fontSize: 13, color: 'var(--grey-mid)', lineHeight: 1.7 }}>
                Firsthand has verified that this source has employer-reported evidence connecting them to{' '}
                <strong style={{ color: 'var(--charcoal)', fontWeight: 500 }}>{selectedCredential?.organization || tip.organization}</strong> during{' '}
                <strong style={{ color: 'var(--charcoal)', fontWeight: 500 }}>{selectedCredential?.year || tip.year}</strong>.
                The credential belongs to the same person submitting this tip.
              </p>
            </Card>
            <Card style={{ padding: 18, borderLeft: '3px solid #FCD34D' }}>
              <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: '#92400E', marginBottom: 10 }}>What Firsthand does not verify</p>
              <p style={{ fontSize: 13, color: 'var(--grey-mid)', lineHeight: 1.7 }}>
                Firsthand does not verify that the claims in this submission are true. All allegations require independent journalistic investigation, source corroboration, and legal review before publication.
              </p>
            </Card>
          </div>

          {/* Tip content */}
          <Card style={{ marginBottom: 16, overflow: 'hidden' }}>
            <button onClick={() => setTipOpen(o => !o)} style={{ width: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 18px', background: 'none', border: 'none', borderBottom: tipOpen ? '1px solid var(--grey-light)' : 'none', cursor: 'pointer' }}>
              <p style={{ fontSize: 12, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--grey-mid)' }}>Confidential tip content</p>
              <span style={{ color: 'var(--grey-mid)', fontSize: 15, transform: tipOpen ? 'none' : 'rotate(-90deg)', transition: 'transform 0.2s' }}>↓</span>
            </button>
            {tipOpen && (
              <div style={{ padding: '18px 18px' }}>
                {tip.what ? (
                  <>
                    <p style={{ fontSize: 14, color: 'var(--charcoal)', lineHeight: 1.75, whiteSpace: 'pre-wrap', marginBottom: tip.context ? 16 : 0 }}>{tip.what}</p>
                    {tip.context && (
                      <>
                        <p style={{ fontSize: 11, color: 'var(--grey-mid)', marginBottom: 6, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Additional context</p>
                        <p style={{ fontSize: 13, color: 'var(--charcoal)', lineHeight: 1.7, whiteSpace: 'pre-wrap' }}>{tip.context}</p>
                      </>
                    )}
                  </>
                ) : (
                  <p style={{ fontSize: 14, color: 'var(--grey-mid)', fontStyle: 'italic' }}>No tip content was entered in this session.</p>
                )}
              </div>
            )}
          </Card>

          {/* Evidence */}
          {tip.files.length > 0 && (
            <Card style={{ padding: 18 }}>
              <p style={{ fontSize: 12, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--grey-mid)', marginBottom: 14 }}>Attached evidence</p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {tip.files.map(f => (
                  <div key={f} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 14px', background: 'var(--grey-faint)', border: '1px solid var(--grey-light)', borderRadius: 4, cursor: 'pointer' }}>
                    <I.Clip s={13} />
                    <span style={{ fontSize: 13, color: 'var(--charcoal)', flex: 1 }}>{f}</span>
                    <span style={{ fontSize: 12, color: 'var(--maroon)', fontWeight: 500 }}>Download</span>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

// ═══════════════════════════════════════════════════════════════════════════════
// ROOT
// ═══════════════════════════════════════════════════════════════════════════════

export default function App() {
  const [screen, setScreen] = useState<Screen>('homepage')

  // Credential flow state
  const [verifyOrg, setVerifyOrg] = useState('Acme Technologies')
  const [verifyYear, setVerifyYear] = useState('2025')
  const [latestCredential, setLatestCredential] = useState<Credential | null>(null)

  // Shared credential wallet (pre-seeded + any issued credentials saved in this browser)
  const [credentials, setCredentials] = useState<Credential[]>(() => {
    const savedCredentials = localStorage.getItem('firsthand-credentials')

    if (savedCredentials) {
      try {
        return JSON.parse(savedCredentials)
      } catch {
        return SEED_CREDENTIALS
      }
    }

    return SEED_CREDENTIALS
  })

  // Persist the credential wallet whenever it changes so issued credentials survive refreshes.
  useEffect(() => {
    localStorage.setItem(
      'firsthand-credentials',
      JSON.stringify(credentials)
    )
  }, [credentials])

  // Tip flow state (independent from credential flow)
  const [tip, setTip] = useState<TipData>(DEFAULT_TIP)

  // Selected credential for tip — set by user in choose-credential screen.
  // NOTE: No matching logic is implemented. selectedCredentialId is set by the user's click.
  // Implement credential-to-tip verification logic manually in CredentialProofReview or here.
  const [selectedCredentialId, setSelectedCredentialId] = useState<string | null>(null)

  const [submissionId] = useState(makeSubmissionId)

  const selectedCredential = credentials.find(c => c.id === selectedCredentialId) ?? null

  const navigate = (s: Screen) => {
    window.scrollTo({ top: 0, behavior: 'instant' })
    setScreen(s)
  }

  const handleCredentialIssued = (cred: Credential) => {
    setLatestCredential(cred)
    setCredentials(prev => [cred, ...prev])
  }

  return (
    <div style={{ minHeight: '100%', background: 'var(--bg)' }}>
      <Nav screen={screen} credentials={credentials} onNavigate={navigate} />

      {screen === 'homepage' && <Homepage onNavigate={navigate} />}

      {/* Flow 1: Get a Verified Credential */}
      {screen === 'verify-employment' && (
        <VerifyEmployment
          verifyOrg={verifyOrg} setVerifyOrg={setVerifyOrg}
          verifyYear={verifyYear} setVerifyYear={setVerifyYear}
          onNavigate={navigate}
        />
      )}
      {screen === 'authorize-verification' && (
        <AuthorizeVerification
          verifyOrg={verifyOrg} verifyYear={verifyYear}
          onCredentialIssued={handleCredentialIssued}
          onNavigate={navigate}
        />
      )}
      {screen === 'credential-issued' && (
        <CredentialIssued latestCredential={latestCredential} onNavigate={navigate} />
      )}
      {screen === 'credential-wallet' && (
        <CredentialWallet credentials={credentials} onNavigate={navigate} />
      )}

      {/* Flow 2: Submit a Tip */}
      {screen === 'submit-tip' && (
        <SubmitTip tip={tip} onChange={setTip} onNavigate={navigate} />
      )}
      {screen === 'choose-credential' && (
        <ChooseCredential
          credentials={credentials}
          selectedCredentialId={selectedCredentialId}
          setSelectedCredentialId={setSelectedCredentialId}
          onNavigate={navigate}
        />
      )}
      {screen === 'credential-proof-review' && (
        <CredentialProofReview
          tip={tip}
          selectedCredential={selectedCredential}
          onNavigate={navigate}
        />
      )}
      {screen === 'submission-success' && (
        <SubmissionSuccess
          tip={tip}
          selectedCredential={selectedCredential}
          submissionId={submissionId}
          onNavigate={navigate}
        />
      )}
      {screen === 'journalist-view' && (
        <JournalistView
          tip={tip}
          selectedCredential={selectedCredential}
          submissionId={submissionId}
          onNavigate={navigate}
        />
      )}
    </div>
  )
}
