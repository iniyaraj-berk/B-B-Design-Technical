import { useState, useEffect, useRef } from 'react'

// ─── Types ────────────────────────────────────────────────────────────────────

type Screen =
  | 'homepage'
  | 'submit-tip'
  | 'verify-connection'
  | 'authorize-verification'
  | 'credential-issued'
  | 'choose-proof'
  | 'submission-success'
  | 'journalist-view'

interface TipData {
  organization: string
  year: string
  what: string
  files: string[]
}

interface Credential {
  id: string
  organization: string
  year: string
  issuedAt: string
}

interface AppState {
  tip: TipData
  credential: Credential | null
  submissionId: string
}

// ─── Icons ────────────────────────────────────────────────────────────────────

function CheckCircle({ size = 20, className = '' }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 20 20" fill="none" className={className}>
      <circle cx="10" cy="10" r="9" stroke="currentColor" strokeWidth="1.5" />
      <path d="M6.5 10.25l2.5 2.5 4.5-5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function Check({ size = 16, className = '' }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" className={className}>
      <path d="M3 8.5l3.5 3.5 6.5-7.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function Shield({ size = 20, className = '' }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 20 20" fill="none" className={className}>
      <path d="M10 2L3 5v5c0 4 3 7 7 8 4-1 7-4 7-8V5l-7-3z" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
      <path d="M7 10l2 2 4-4" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function Lock({ size = 16, className = '' }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" className={className}>
      <rect x="3" y="7" width="10" height="8" rx="1.5" stroke="currentColor" strokeWidth="1.3" />
      <path d="M5 7V5a3 3 0 0 1 6 0v2" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
      <circle cx="8" cy="11" r="1" fill="currentColor" />
    </svg>
  )
}

function EyeOff({ size = 16, className = '' }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 16 16" fill="none" className={className}>
      <path d="M2 2l12 12M6.5 6.56A2 2 0 0 0 9.44 9.5M4.25 4.29C2.85 5.28 1.67 6.93 1 8c1.28 2.12 4.05 5 7 5 1.27 0 2.44-.43 3.45-1.05M7 3.1C7.32 3.04 7.66 3 8 3c2.95 0 5.72 2.88 7 5a14.6 14.6 0 0 1-1.5 2.14" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" />
    </svg>
  )
}

function ArrowRight({ size = 14, className = '' }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 14 14" fill="none" className={className}>
      <path d="M3 7h8M8 4l3 3-3 3" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function Paperclip({ size = 15, className = '' }: { size?: number; className?: string }) {
  return (
    <svg width={size} height={size} viewBox="0 0 15 15" fill="none" className={className}>
      <path d="M12.5 6.5L6 13a3.5 3.5 0 0 1-5-5L7 2a2.333 2.333 0 0 1 3.3 3.3L4 11.6A1.167 1.167 0 0 1 2.4 10l6.1-6.1" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

// ─── Small Components ─────────────────────────────────────────────────────────

function Chip({ children, accent }: { children: React.ReactNode; accent?: boolean }) {
  return (
    <span
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 5,
        padding: '3px 10px',
        borderRadius: 100,
        fontSize: 11,
        fontWeight: 500,
        letterSpacing: '0.04em',
        textTransform: 'uppercase',
        background: accent ? 'var(--maroon-tint)' : 'var(--grey-faint)',
        color: accent ? 'var(--maroon)' : 'var(--grey-mid)',
        border: `1px solid ${accent ? 'rgba(104,27,43,0.2)' : 'var(--grey-light)'}`,
      }}
    >
      {children}
    </span>
  )
}

function PrivacyBanner({ text }: { text: string }) {
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      padding: '10px 14px',
      background: 'var(--maroon-tint)',
      border: '1px solid rgba(104,27,43,0.18)',
      borderRadius: 'var(--radius)',
      fontSize: 13,
      color: 'var(--charcoal)',
      fontWeight: 500,
    }}>
      <EyeOff size={14} className="flex-shrink-0" style={{ color: 'var(--maroon)' } as React.CSSProperties} />
      {text}
    </div>
  )
}

function FormField({
  label, hint, children,
}: {
  label: string
  hint?: string
  children: React.ReactNode
}) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
      <label style={{ fontSize: 13, fontWeight: 500, color: 'var(--charcoal)' }}>{label}</label>
      {hint && <p style={{ fontSize: 12, color: 'var(--grey-mid)', marginTop: -2 }}>{hint}</p>}
      {children}
    </div>
  )
}

const inputStyle: React.CSSProperties = {
  width: '100%',
  border: '1px solid var(--grey-light)',
  borderRadius: 'var(--radius)',
  padding: '10px 12px',
  fontSize: 14,
  color: 'var(--charcoal)',
  background: 'var(--white)',
  boxSizing: 'border-box',
}

function PrimaryButton({
  onClick,
  disabled,
  children,
  fullWidth,
}: {
  onClick?: () => void
  disabled?: boolean
  children: React.ReactNode
  fullWidth?: boolean
}) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 8,
        width: fullWidth ? '100%' : undefined,
        padding: '12px 24px',
        background: disabled ? 'var(--grey-light)' : 'var(--maroon)',
        color: disabled ? 'var(--grey-mid)' : 'var(--white)',
        border: 'none',
        borderRadius: 'var(--radius)',
        fontSize: 14,
        fontWeight: 500,
        cursor: disabled ? 'not-allowed' : 'pointer',
        letterSpacing: '0.01em',
      }}
      onMouseEnter={e => { if (!disabled) (e.currentTarget as HTMLButtonElement).style.background = 'var(--maroon-dark)' }}
      onMouseLeave={e => { if (!disabled) (e.currentTarget as HTMLButtonElement).style.background = 'var(--maroon)' }}
    >
      {children}
    </button>
  )
}

function GhostButton({
  onClick,
  children,
}: {
  onClick?: () => void
  children: React.ReactNode
}) {
  return (
    <button
      onClick={onClick}
      style={{
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        padding: '12px 24px',
        background: 'transparent',
        color: 'var(--charcoal)',
        border: '1px solid var(--grey-light)',
        borderRadius: 'var(--radius)',
        fontSize: 14,
        fontWeight: 500,
        cursor: 'pointer',
      }}
      onMouseEnter={e => { (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--charcoal)' }}
      onMouseLeave={e => { (e.currentTarget as HTMLButtonElement).style.borderColor = 'var(--grey-light)' }}
    >
      {children}
    </button>
  )
}

// ─── Navigation ───────────────────────────────────────────────────────────────

function Nav({ isJournalist, onNavigate }: { isJournalist: boolean; onNavigate: (s: Screen) => void }) {
  return (
    <div style={{
      position: 'sticky',
      top: 0,
      zIndex: 100,
      background: 'rgba(255,255,255,0.96)',
      backdropFilter: 'blur(8px)',
      borderBottom: '1px solid var(--grey-light)',
    }}>
      <div style={{
        maxWidth: 1200,
        margin: '0 auto',
        padding: '0 48px',
        height: 60,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
        <button
          onClick={() => onNavigate('homepage')}
          style={{
            fontFamily: 'Playfair Display, Georgia, serif',
            fontSize: 20,
            fontWeight: 600,
            color: 'var(--charcoal)',
            background: 'none',
            border: 'none',
            cursor: 'pointer',
            letterSpacing: '-0.02em',
          }}
        >
          Firsthand
        </button>

        {isJournalist ? (
          <Chip>Journalist Dashboard</Chip>
        ) : (
          <div style={{ display: 'flex', alignItems: 'center', gap: 32 }}>
            {['How it works', 'For Journalists'].map(label => (
              <button
                key={label}
                style={{ fontSize: 14, color: 'var(--grey-mid)', background: 'none', border: 'none', cursor: 'pointer' }}
                onMouseEnter={e => (e.currentTarget.style.color = 'var(--charcoal)')}
                onMouseLeave={e => (e.currentTarget.style.color = 'var(--grey-mid)')}
              >
                {label}
              </button>
            ))}
            <button
              style={{
                fontSize: 14,
                fontWeight: 500,
                color: 'var(--charcoal)',
                background: 'none',
                border: '1px solid var(--grey-light)',
                borderRadius: 'var(--radius)',
                padding: '6px 16px',
                cursor: 'pointer',
              }}
              onMouseEnter={e => (e.currentTarget.style.borderColor = 'var(--charcoal)')}
              onMouseLeave={e => (e.currentTarget.style.borderColor = 'var(--grey-light)')}
            >
              Sign in
            </button>
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Page Shell ───────────────────────────────────────────────────────────────

function PageShell({ children, maxWidth = 600 }: { children: React.ReactNode; maxWidth?: number }) {
  return (
    <div style={{
      maxWidth: 1200,
      margin: '0 auto',
      padding: '0 48px',
    }}>
      <div style={{ maxWidth, margin: '0 auto', paddingTop: 64, paddingBottom: 80 }}>
        {children}
      </div>
    </div>
  )
}

function StepLabel({ step, total }: { step: number; total: number }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 28 }}>
      {Array.from({ length: total }, (_, i) => (
        <div
          key={i}
          style={{
            height: 3,
            width: i === step - 1 ? 32 : 16,
            borderRadius: 2,
            background: i < step ? 'var(--maroon)' : 'var(--grey-light)',
            transition: 'all 0.3s ease',
          }}
        />
      ))}
      <span style={{ fontSize: 12, color: 'var(--grey-mid)', marginLeft: 4 }}>
        Step {step} of {total}
      </span>
    </div>
  )
}

function SectionHeading({ kicker, title, body }: { kicker?: string; title: string; body?: string }) {
  return (
    <div style={{ marginBottom: 36 }}>
      {kicker && (
        <p style={{
          fontSize: 11,
          fontWeight: 600,
          letterSpacing: '0.08em',
          textTransform: 'uppercase',
          color: 'var(--maroon)',
          marginBottom: 12,
        }}>
          {kicker}
        </p>
      )}
      <h1 style={{
        fontFamily: 'Playfair Display, Georgia, serif',
        fontSize: 40,
        fontWeight: 600,
        color: 'var(--charcoal)',
        lineHeight: 1.15,
        letterSpacing: '-0.02em',
        marginBottom: body ? 14 : 0,
      }}>
        {title}
      </h1>
      {body && (
        <p style={{ fontSize: 15, color: 'var(--grey-mid)', lineHeight: 1.65, maxWidth: 520 }}>
          {body}
        </p>
      )}
    </div>
  )
}

function Card({ children, style }: { children: React.ReactNode; style?: React.CSSProperties }) {
  return (
    <div style={{
      background: 'var(--white)',
      border: '1px solid var(--grey-light)',
      borderRadius: 'var(--radius-lg)',
      ...style,
    }}>
      {children}
    </div>
  )
}

// ─── Credential Card ──────────────────────────────────────────────────────────

function CredentialCard({ org, year, compact }: { org: string; year: string; compact?: boolean }) {
  return (
    <div style={{
      background: 'var(--white)',
      border: '1.5px solid var(--maroon)',
      borderRadius: compact ? 'var(--radius)' : 'var(--radius-lg)',
      overflow: 'hidden',
      boxShadow: compact ? 'none' : '0 4px 24px rgba(104,27,43,0.1)',
    }}>
      {/* Top bar */}
      <div style={{
        background: 'var(--maroon)',
        padding: compact ? '8px 16px' : '12px 24px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Check size={compact ? 13 : 15} className="" style={{ color: 'white' } as React.CSSProperties} />
          <span style={{
            fontFamily: 'Playfair Display, serif',
            fontSize: compact ? 12 : 13,
            fontWeight: 600,
            color: 'white',
            letterSpacing: '0.04em',
            textTransform: 'uppercase',
          }}>
            Firsthand Verified
          </span>
        </div>
        <span style={{ fontSize: 10, color: 'rgba(255,255,255,0.6)', fontWeight: 400, letterSpacing: '0.03em' }}>
          VERIFIED EMPLOYMENT CREDENTIAL
        </span>
      </div>

      {/* Body */}
      <div style={{ padding: compact ? '14px 16px' : '24px', background: 'var(--maroon-tint)' }}>
        <p style={{
          fontFamily: 'Playfair Display, serif',
          fontSize: compact ? 18 : 26,
          fontWeight: 600,
          color: 'var(--charcoal)',
          letterSpacing: '-0.01em',
          marginBottom: 4,
        }}>
          {org}
        </p>
        <p style={{ fontSize: compact ? 12 : 13, color: 'var(--grey-mid)' }}>
          Employment activity verified · {year}
        </p>

        {!compact && (
          <div style={{
            marginTop: 20,
            paddingTop: 20,
            borderTop: '1px solid rgba(104,27,43,0.15)',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
          }}>
            <div>
              <p style={{ fontSize: 11, color: 'var(--grey-mid)', marginBottom: 3 }}>Issued by</p>
              <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--charcoal)' }}>Firsthand</p>
            </div>
            <div style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 6,
              padding: '5px 12px',
              background: 'rgba(104,27,43,0.08)',
              border: '1px solid rgba(104,27,43,0.2)',
              borderRadius: 100,
            }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#2D8A4E' }} />
              <span style={{ fontSize: 11, fontWeight: 500, color: 'var(--maroon)' }}>Active · Non-transferable</span>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

// ─── Screen 1 — Homepage ──────────────────────────────────────────────────────

function Homepage({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  return (
    <div>
      {/* Hero */}
      <div style={{ background: 'var(--white)', borderBottom: '1px solid var(--grey-light)' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 48px' }}>
          <div style={{ maxWidth: 720, paddingTop: 96, paddingBottom: 80 }}>
            <Chip accent>Privacy-protected source verification</Chip>
            <h1 style={{
              fontFamily: 'Playfair Display, Georgia, serif',
              fontSize: 68,
              fontWeight: 600,
              lineHeight: 1.08,
              letterSpacing: '-0.03em',
              color: 'var(--charcoal)',
              marginTop: 24,
              marginBottom: 24,
            }}>
              Share what you know.<br />
              <span style={{ color: 'var(--maroon)', fontStyle: 'italic' }}>Without sharing</span><br />
              who you are.
            </h1>
            <p style={{
              fontSize: 18,
              color: 'var(--grey-mid)',
              lineHeight: 1.65,
              marginBottom: 40,
              maxWidth: 520,
              fontWeight: 300,
            }}>
              Firsthand lets you share information with journalists while privately proving that you have a real connection to the story.
            </p>
            <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
              <PrimaryButton onClick={() => onNavigate('submit-tip')}>
                Submit a confidential tip
              </PrimaryButton>
              <button
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 6,
                  fontSize: 14,
                  color: 'var(--grey-mid)',
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  textDecoration: 'underline',
                  textDecorationColor: 'var(--grey-light)',
                  textUnderlineOffset: 3,
                }}
                onMouseEnter={e => (e.currentTarget.style.color = 'var(--charcoal)')}
                onMouseLeave={e => (e.currentTarget.style.color = 'var(--grey-mid)')}
              >
                How Firsthand protects you <ArrowRight />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Three-part explanation */}
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '80px 48px' }}>
        <p style={{
          fontSize: 11,
          fontWeight: 600,
          letterSpacing: '0.08em',
          textTransform: 'uppercase',
          color: 'var(--grey-mid)',
          marginBottom: 48,
        }}>
          How it works
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 1, background: 'var(--grey-light)' }}>
          {[
            {
              n: '01',
              title: 'Share securely',
              body: 'Tell us what happened without exposing your identity. Your name and personal information are never included in your submission.',
              icon: <EyeOff size={20} />,
            },
            {
              n: '02',
              title: 'Verify privately',
              body: 'Firsthand privately verifies your connection to the organization using employer-reported records. Your employment documents stay private.',
              icon: <Shield size={20} />,
            },
            {
              n: '03',
              title: 'Be credible without being identified',
              body: 'Journalists receive proof of your verified connection to the organization — not your identity. They can trust the source without knowing who you are.',
              icon: <CheckCircle size={20} />,
            },
          ].map(item => (
            <div
              key={item.n}
              style={{
                background: 'var(--white)',
                padding: '40px 36px',
              }}
            >
              <p style={{
                fontFamily: 'Playfair Display, serif',
                fontSize: 36,
                fontWeight: 400,
                color: 'var(--grey-light)',
                marginBottom: 20,
                lineHeight: 1,
              }}>
                {item.n}
              </p>
              <div style={{ color: 'var(--maroon)', marginBottom: 16 }}>{item.icon}</div>
              <h3 style={{
                fontFamily: 'Playfair Display, serif',
                fontSize: 20,
                fontWeight: 600,
                color: 'var(--charcoal)',
                marginBottom: 12,
                lineHeight: 1.3,
              }}>
                {item.title}
              </h3>
              <p style={{ fontSize: 14, color: 'var(--grey-mid)', lineHeight: 1.7 }}>{item.body}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Dark strip CTA */}
      <div style={{ background: 'var(--charcoal)', padding: '64px 48px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <h2 style={{
              fontFamily: 'Playfair Display, serif',
              fontSize: 32,
              fontWeight: 600,
              color: 'white',
              letterSpacing: '-0.02em',
              marginBottom: 10,
            }}>
              Ready to share what you know?
            </h2>
            <p style={{ fontSize: 15, color: 'rgba(255,255,255,0.5)', fontWeight: 300 }}>
              Your identity stays private. Your connection gets verified. Your information reaches journalists.
            </p>
          </div>
          <button
            onClick={() => onNavigate('submit-tip')}
            style={{
              padding: '14px 28px',
              background: 'var(--maroon)',
              color: 'white',
              border: 'none',
              borderRadius: 'var(--radius)',
              fontSize: 14,
              fontWeight: 500,
              cursor: 'pointer',
              whiteSpace: 'nowrap',
              flexShrink: 0,
              marginLeft: 48,
            }}
            onMouseEnter={e => (e.currentTarget.style.background = 'var(--maroon-dark)')}
            onMouseLeave={e => (e.currentTarget.style.background = 'var(--maroon)')}
          >
            Submit a confidential tip
          </button>
        </div>
      </div>

      {/* Footer */}
      <div style={{ borderTop: '1px solid var(--grey-light)', padding: '24px 48px' }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <span style={{ fontFamily: 'Playfair Display, serif', fontSize: 14, color: 'var(--grey-mid)' }}>Firsthand</span>
          <p style={{ fontSize: 12, color: 'var(--grey-mid)' }}>Not affiliated with any news organization. Privacy-protected source verification.</p>
        </div>
      </div>
    </div>
  )
}

// ─── Screen 2 — Submit Tip ────────────────────────────────────────────────────

function SubmitTip({
  tip,
  onChange,
  onNavigate,
}: {
  tip: TipData
  onChange: (t: TipData) => void
  onNavigate: (s: Screen) => void
}) {
  const [dragOver, setDragOver] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)

  const handleFiles = (fileList: FileList) => {
    const names = Array.from(fileList).map(f => f.name)
    onChange({ ...tip, files: [...tip.files, ...names.filter(n => !tip.files.includes(n))] })
  }

  const removeFile = (name: string) => {
    onChange({ ...tip, files: tip.files.filter(f => f !== name) })
  }

  const canContinue = tip.organization.trim().length > 0 && tip.what.trim().length > 0

  return (
    <PageShell>
      <StepLabel step={1} total={6} />
      <SectionHeading
        kicker="Confidential submission"
        title="Submit a confidential tip"
        body="Tell us what happened. Your identity will not be attached to this submission at any point in this process."
      />

      <PrivacyBanner text="Your identity will not be attached to this submission." />

      <div style={{ marginTop: 28, display: 'flex', flexDirection: 'column', gap: 20 }}>
        <FormField label="Organization" hint="The organization this tip concerns">
          <input
            style={inputStyle}
            placeholder="e.g. Acme Technologies"
            value={tip.organization}
            onChange={e => onChange({ ...tip, organization: e.target.value })}
          />
        </FormField>

        <FormField label="When did this happen?" hint="The approximate year or period">
          <select
            style={inputStyle}
            value={tip.year}
            onChange={e => onChange({ ...tip, year: e.target.value })}
          >
            {['2025', '2024', '2023', '2022', '2021', '2020'].map(y => (
              <option key={y} value={y}>{y}</option>
            ))}
          </select>
        </FormField>

        <FormField label="What happened?" hint="Describe what you witnessed or experienced">
          <textarea
            style={{ ...inputStyle, minHeight: 160, resize: 'vertical', lineHeight: 1.65 }}
            placeholder="Be as specific as possible — dates, people involved, documents referenced, decisions made…"
            value={tip.what}
            onChange={e => onChange({ ...tip, what: e.target.value })}
          />
        </FormField>

        <FormField label="Supporting evidence" hint="Optional — documents, images, or other files">
          <div
            onDragOver={e => { e.preventDefault(); setDragOver(true) }}
            onDragLeave={() => setDragOver(false)}
            onDrop={e => {
              e.preventDefault()
              setDragOver(false)
              if (e.dataTransfer.files) handleFiles(e.dataTransfer.files)
            }}
            onClick={() => fileRef.current?.click()}
            style={{
              border: `1.5px dashed ${dragOver ? 'var(--maroon)' : 'var(--grey-light)'}`,
              borderRadius: 'var(--radius)',
              padding: '28px 20px',
              textAlign: 'center',
              cursor: 'pointer',
              background: dragOver ? 'var(--maroon-tint)' : 'var(--white)',
              transition: 'all 0.15s',
            }}
          >
            <input
              ref={fileRef}
              type="file"
              multiple
              style={{ display: 'none' }}
              onChange={e => { if (e.target.files) handleFiles(e.target.files) }}
            />
            <Paperclip size={20} style={{ color: 'var(--grey-mid)', margin: '0 auto 8px' } as React.CSSProperties} />
            <p style={{ fontSize: 13, color: 'var(--grey-mid)' }}>
              Drop files here or <span style={{ color: 'var(--maroon)', textDecoration: 'underline' }}>browse</span>
            </p>
            <p style={{ fontSize: 11, color: 'var(--grey-mid)', marginTop: 4 }}>
              Documents, images, spreadsheets — any format accepted
            </p>
          </div>

          {tip.files.length > 0 && (
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 10 }}>
              {tip.files.map(f => (
                <div
                  key={f}
                  style={{
                    display: 'inline-flex',
                    alignItems: 'center',
                    gap: 6,
                    padding: '4px 10px 4px 8px',
                    background: 'var(--grey-faint)',
                    border: '1px solid var(--grey-light)',
                    borderRadius: 'var(--radius)',
                    fontSize: 12,
                    color: 'var(--charcoal)',
                  }}
                >
                  <Paperclip size={12} style={{ color: 'var(--grey-mid)' } as React.CSSProperties} />
                  {f}
                  <button
                    onClick={e => { e.stopPropagation(); removeFile(f) }}
                    style={{
                      marginLeft: 4,
                      padding: 0,
                      background: 'none',
                      border: 'none',
                      cursor: 'pointer',
                      color: 'var(--grey-mid)',
                      lineHeight: 1,
                      fontSize: 14,
                    }}
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}
        </FormField>
      </div>

      <div style={{ marginTop: 32 }}>
        <PrimaryButton
          onClick={() => onNavigate('verify-connection')}
          disabled={!canContinue}
          fullWidth
        >
          Continue <ArrowRight />
        </PrimaryButton>
        {!canContinue && (
          <p style={{ fontSize: 12, color: 'var(--grey-mid)', marginTop: 8, textAlign: 'center' }}>
            Please fill in the organization and what happened before continuing.
          </p>
        )}
      </div>
    </PageShell>
  )
}

// ─── Screen 3 — Verify Connection ─────────────────────────────────────────────

function VerifyConnection({
  tip,
  onNavigate,
}: {
  tip: TipData
  onNavigate: (s: Screen) => void
}) {
  return (
    <PageShell>
      <StepLabel step={2} total={6} />

      <SectionHeading
        kicker="Employment verification"
        title={`Verify your connection to ${tip.organization}`}
        body="Firsthand privately verifies employment records so journalists can know you have a legitimate connection to the organization — without learning who you are."
      />

      <Card style={{ padding: 28, marginBottom: 20 }}>
        <p style={{ fontSize: 12, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--grey-mid)', marginBottom: 16 }}>
          Your tip concerns
        </p>
        <div style={{ display: 'flex', gap: 32 }}>
          <div>
            <p style={{ fontSize: 11, color: 'var(--grey-mid)', marginBottom: 4 }}>Organization</p>
            <p style={{ fontSize: 17, fontWeight: 600, color: 'var(--charcoal)', fontFamily: 'Playfair Display, serif' }}>
              {tip.organization}
            </p>
          </div>
          <div>
            <p style={{ fontSize: 11, color: 'var(--grey-mid)', marginBottom: 4 }}>Period</p>
            <p style={{ fontSize: 17, fontWeight: 600, color: 'var(--charcoal)', fontFamily: 'Playfair Display, serif' }}>
              {tip.year}
            </p>
          </div>
        </div>
      </Card>

      <Card style={{ padding: 28, marginBottom: 28 }}>
        <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--charcoal)', marginBottom: 16 }}>
          How verification works
        </p>
        {[
          {
            step: '1',
            text: 'Firsthand requests permission to access employer-reported employment records.',
          },
          {
            step: '2',
            text: 'Records are matched against the organization and period you specified.',
          },
          {
            step: '3',
            text: 'If verified, Firsthand issues you a Verified Employment Credential.',
          },
          {
            step: '4',
            text: 'The credential can be attached to your tip — proving your connection without revealing your identity.',
          },
        ].map(item => (
          <div key={item.step} style={{ display: 'flex', gap: 14, marginBottom: 16, alignItems: 'flex-start' }}>
            <div style={{
              width: 22,
              height: 22,
              borderRadius: '50%',
              background: 'var(--grey-faint)',
              border: '1px solid var(--grey-light)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
              fontSize: 11,
              fontWeight: 600,
              color: 'var(--grey-mid)',
            }}>
              {item.step}
            </div>
            <p style={{ fontSize: 14, color: 'var(--grey-mid)', lineHeight: 1.6, paddingTop: 2 }}>{item.text}</p>
          </div>
        ))}
      </Card>

      <div style={{
        display: 'flex',
        alignItems: 'flex-start',
        gap: 10,
        padding: '14px 16px',
        background: 'var(--grey-faint)',
        border: '1px solid var(--grey-light)',
        borderRadius: 'var(--radius)',
        marginBottom: 28,
      }}>
        <Lock size={15} style={{ color: 'var(--grey-mid)', flexShrink: 0, marginTop: 1 } as React.CSSProperties} />
        <p style={{ fontSize: 13, color: 'var(--grey-mid)', lineHeight: 1.6 }}>
          <strong style={{ color: 'var(--charcoal)', fontWeight: 500 }}>Your underlying records will never be shown to journalists.</strong>{' '}
          Verification is conducted privately and only the result — verified or not — is ever disclosed.
        </p>
      </div>

      <PrimaryButton onClick={() => onNavigate('authorize-verification')} fullWidth>
        Verify my employment <ArrowRight />
      </PrimaryButton>
    </PageShell>
  )
}

// ─── Screen 4 — Authorize Verification ───────────────────────────────────────

function AuthorizeVerification({
  tip,
  onIssued,
  onNavigate,
}: {
  tip: TipData
  onIssued: (c: Credential) => void
  onNavigate: (s: Screen) => void
}) {
  const [phase, setPhase] = useState<'idle' | 'loading' | 'done'>('idle')
  const [progress, setProgress] = useState(0)
  const [statusText, setStatusText] = useState('')

  const steps = [
    'Connecting to employer-reported records…',
    'Verifying identity match…',
    `Confirming employment at ${tip.organization}…`,
    `Confirming activity during ${tip.year}…`,
    'Issuing Verified Employment Credential…',
  ]

  const authorize = () => {
    setPhase('loading')
    let p = 0
    let stepIndex = 0
    setStatusText(steps[0])

    const interval = setInterval(() => {
      p += 4 + Math.random() * 6
      if (p >= 100) {
        p = 100
        clearInterval(interval)
        setProgress(100)
        setStatusText('Verification complete.')
        const cred: Credential = {
          id: `FH-${tip.year}-${tip.organization.slice(0, 3).toUpperCase()}-${Math.floor(Math.random() * 9000 + 1000)}`,
          organization: tip.organization,
          year: tip.year,
          issuedAt: new Date().toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' }),
        }
        onIssued(cred)
        setTimeout(() => { setPhase('done'); setTimeout(() => onNavigate('credential-issued'), 600) }, 600)
        return
      }
      const newStepIndex = Math.floor((p / 100) * steps.length)
      if (newStepIndex !== stepIndex && newStepIndex < steps.length) {
        stepIndex = newStepIndex
        setStatusText(steps[stepIndex])
      }
      setProgress(p)
    }, 200)
  }

  return (
    <PageShell>
      <StepLabel step={3} total={6} />
      <SectionHeading
        kicker="Authorization required"
        title="Authorize employment verification"
        body="Before Firsthand can issue your credential, you need to authorize access to the following information."
      />

      {/* Permission list */}
      <Card style={{ marginBottom: 20, overflow: 'hidden' }}>
        <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--grey-light)', background: 'var(--grey-faint)' }}>
          <p style={{ fontSize: 12, fontWeight: 600, color: 'var(--grey-mid)', letterSpacing: '0.06em', textTransform: 'uppercase' }}>
            Firsthand is requesting permission to privately verify
          </p>
        </div>
        {[
          { label: 'Your identity', note: 'Used for verification only — never shared with journalists' },
          { label: `Your connection to ${tip.organization}`, note: 'Employer-reported records accessed privately' },
          { label: `Employment activity during ${tip.year}`, note: 'Period confirmed and included in credential' },
        ].map((item, i) => (
          <div
            key={i}
            style={{
              display: 'flex',
              alignItems: 'flex-start',
              gap: 14,
              padding: '16px 20px',
              borderBottom: i < 2 ? '1px solid var(--grey-light)' : 'none',
            }}
          >
            <div style={{
              width: 20,
              height: 20,
              borderRadius: '50%',
              background: 'rgba(104,27,43,0.08)',
              border: '1px solid rgba(104,27,43,0.2)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
              marginTop: 1,
            }}>
              <Check size={11} style={{ color: 'var(--maroon)' } as React.CSSProperties} />
            </div>
            <div>
              <p style={{ fontSize: 14, fontWeight: 500, color: 'var(--charcoal)' }}>{item.label}</p>
              <p style={{ fontSize: 12, color: 'var(--grey-mid)', marginTop: 2 }}>{item.note}</p>
            </div>
          </div>
        ))}
      </Card>

      {/* Used for / shared with */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 24 }}>
        <Card style={{ padding: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 14 }}>
            <Lock size={13} style={{ color: 'var(--maroon)' } as React.CSSProperties} />
            <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--maroon)' }}>
              Used for private verification
            </p>
          </div>
          {['Identity', 'Employment records', 'Personal documents'].map(item => (
            <div key={item} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
              <Lock size={12} style={{ color: 'var(--grey-mid)' } as React.CSSProperties} />
              <span style={{ fontSize: 13, color: 'var(--charcoal)' }}>{item}</span>
            </div>
          ))}
        </Card>
        <Card style={{ padding: 20 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 14 }}>
            <Check size={13} style={{ color: 'var(--maroon)' } as React.CSSProperties} />
            <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--maroon)' }}>
              Shared with journalist
            </p>
          </div>
          {[`Verified connection to ${tip.organization}`, `Employment activity · ${tip.year}`].map(item => (
            <div key={item} style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginBottom: 10 }}>
              <Check size={12} style={{ color: 'var(--maroon)', marginTop: 2 } as React.CSSProperties} />
              <span style={{ fontSize: 13, color: 'var(--charcoal)' }}>{item}</span>
            </div>
          ))}
        </Card>
      </div>

      {/* Privacy guarantee */}
      <div style={{
        borderLeft: '3px solid var(--maroon)',
        paddingLeft: 16,
        marginBottom: 28,
      }}>
        <p style={{ fontSize: 14, fontWeight: 500, color: 'var(--charcoal)', lineHeight: 1.6 }}>
          "Your identity and underlying employment records remain private. Journalists will only see the result of verification."
        </p>
        <p style={{ fontSize: 12, color: 'var(--grey-mid)', marginTop: 4 }}>Firsthand Privacy Guarantee</p>
      </div>

      {/* Loading state */}
      {phase !== 'idle' ? (
        <Card style={{ padding: 24 }}>
          <div style={{ marginBottom: 14, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <p style={{ fontSize: 14, fontWeight: 500, color: 'var(--charcoal)' }}>
              {phase === 'done' ? 'Verification complete' : statusText}
            </p>
            <span style={{ fontSize: 12, color: 'var(--grey-mid)', fontVariantNumeric: 'tabular-nums' }}>
              {Math.round(progress)}%
            </span>
          </div>
          <div style={{ height: 4, background: 'var(--grey-faint)', borderRadius: 2, overflow: 'hidden' }}>
            <div style={{
              height: '100%',
              background: phase === 'done' ? '#2D8A4E' : 'var(--maroon)',
              borderRadius: 2,
              width: `${progress}%`,
              transition: 'width 0.3s ease',
            }} />
          </div>
          {phase === 'done' && (
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 14 }}>
              <CheckCircle size={16} style={{ color: '#2D8A4E' } as React.CSSProperties} />
              <span style={{ fontSize: 13, color: '#2D8A4E', fontWeight: 500 }}>
                Records verified. Issuing credential…
              </span>
            </div>
          )}
        </Card>
      ) : (
        <PrimaryButton onClick={authorize} fullWidth>
          Authorize &amp; Verify
        </PrimaryButton>
      )}
    </PageShell>
  )
}

// ─── Screen 5 — Credential Issued ────────────────────────────────────────────

function CredentialIssued({
  credential,
  onNavigate,
}: {
  credential: Credential
  onNavigate: (s: Screen) => void
}) {
  const [visible, setVisible] = useState(false)
  useEffect(() => { const t = setTimeout(() => setVisible(true), 80); return () => clearTimeout(t) }, [])

  return (
    <PageShell>
      <div style={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(12px)',
        transition: 'opacity 0.5s ease, transform 0.5s ease',
      }}>
        <div style={{ marginBottom: 10 }}>
          <Chip accent>
            <Check size={11} style={{ color: 'var(--maroon)' } as React.CSSProperties} /> Verification successful
          </Chip>
        </div>

        <SectionHeading
          title="Your connection is verified."
          body={`Firsthand has issued a Verified Employment Credential confirming your connection to ${credential.organization}. This credential is permanently tied to you and cannot be transferred.`}
        />

        {/* THE CREDENTIAL */}
        <div style={{
          opacity: visible ? 1 : 0,
          transform: visible ? 'scale(1)' : 'scale(0.97)',
          transition: 'opacity 0.6s ease 0.2s, transform 0.6s ease 0.2s',
          marginBottom: 28,
        }}>
          <CredentialCard org={credential.organization} year={credential.year} />
        </div>

        {/* Credential metadata */}
        <Card style={{ padding: 20, marginBottom: 28 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 20 }}>
            {[
              { label: 'Credential ID', value: credential.id },
              { label: 'Issued', value: credential.issuedAt },
              { label: 'Status', value: 'Active · Non-transferable', highlight: true },
            ].map(item => (
              <div key={item.label}>
                <p style={{ fontSize: 11, color: 'var(--grey-mid)', marginBottom: 4 }}>{item.label}</p>
                <p style={{ fontSize: 13, fontWeight: 500, color: item.highlight ? '#2D8A4E' : 'var(--charcoal)', fontFamily: item.label === 'Credential ID' ? 'monospace' : 'inherit', letterSpacing: item.label === 'Credential ID' ? '0.03em' : 'inherit' }}>
                  {item.value}
                </p>
              </div>
            ))}
          </div>
        </Card>

        {/* Non-transferable explanation */}
        <div style={{
          display: 'flex',
          gap: 12,
          padding: '16px 18px',
          background: 'var(--grey-faint)',
          border: '1px solid var(--grey-light)',
          borderRadius: 'var(--radius)',
          marginBottom: 32,
        }}>
          <Lock size={15} style={{ color: 'var(--maroon)', flexShrink: 0, marginTop: 1 } as React.CSSProperties} />
          <p style={{ fontSize: 13, color: 'var(--grey-mid)', lineHeight: 1.7 }}>
            <strong style={{ color: 'var(--charcoal)', fontWeight: 500 }}>This credential is permanently tied to you and cannot be transferred.</strong>{' '}
            Firsthand can now prove your connection to {credential.organization} without revealing your identity or underlying employment records. Someone who never worked at this organization cannot use your credential.
          </p>
        </div>

        <PrimaryButton onClick={() => onNavigate('choose-proof')} fullWidth>
          Use this credential <ArrowRight />
        </PrimaryButton>
      </div>
    </PageShell>
  )
}

// ─── Screen 6 — Choose What to Prove ─────────────────────────────────────────

function ChooseProof({
  tip,
  credential,
  onNavigate,
}: {
  tip: TipData
  credential: Credential
  onNavigate: (s: Screen) => void
}) {
  return (
    <PageShell maxWidth={680}>
      <StepLabel step={5} total={6} />
      <SectionHeading
        kicker="Prove your connection"
        title="Prove your connection without revealing your identity."
        body="Firsthand found a matching credential for this submission. Attaching it will prove your insider connection to journalists — without disclosing who you are."
      />

      {/* Matching credential found */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        gap: 12,
        padding: '14px 16px',
        background: 'var(--maroon-tint)',
        border: '1px solid rgba(104,27,43,0.2)',
        borderRadius: 'var(--radius)',
        marginBottom: 24,
      }}>
        <CheckCircle size={18} style={{ color: 'var(--maroon)', flexShrink: 0 } as React.CSSProperties} />
        <div>
          <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--charcoal)' }}>Matching verified credential found</p>
          <p style={{ fontSize: 12, color: 'var(--grey-mid)' }}>
            {credential.organization} · Employment activity verified · {credential.year}
          </p>
        </div>
      </div>

      {/* The two columns */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 28 }}>
        {/* Journalist sees */}
        <Card style={{ overflow: 'hidden' }}>
          <div style={{ padding: '12px 18px', borderBottom: '1px solid var(--grey-light)', background: 'var(--grey-faint)' }}>
            <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--charcoal)' }}>
              The journalist will see
            </p>
          </div>
          <div style={{ padding: '18px' }}>
            {[
              `Verified connection to ${credential.organization}`,
              `Employment activity verified during ${credential.year}`,
              'Credential issued by Firsthand',
            ].map(item => (
              <div key={item} style={{ display: 'flex', alignItems: 'flex-start', gap: 10, marginBottom: 14 }}>
                <div style={{
                  width: 18,
                  height: 18,
                  borderRadius: '50%',
                  background: 'rgba(104,27,43,0.08)',
                  border: '1px solid rgba(104,27,43,0.2)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0,
                  marginTop: 1,
                }}>
                  <Check size={10} style={{ color: 'var(--maroon)' } as React.CSSProperties} />
                </div>
                <span style={{ fontSize: 13, color: 'var(--charcoal)', lineHeight: 1.5 }}>{item}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* What stays private */}
        <Card style={{ overflow: 'hidden' }}>
          <div style={{ padding: '12px 18px', borderBottom: '1px solid var(--grey-light)', background: 'var(--grey-faint)' }}>
            <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--charcoal)' }}>
              Your identity stays private
            </p>
          </div>
          <div style={{ padding: '18px' }}>
            {[
              'Name',
              'Tax & employment documents',
              'Account information',
              'Income information',
              'Other identifying information',
            ].map(item => (
              <div key={item} style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14 }}>
                <div style={{
                  width: 18,
                  height: 18,
                  borderRadius: '50%',
                  background: 'var(--grey-faint)',
                  border: '1px solid var(--grey-light)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0,
                }}>
                  <Lock size={10} style={{ color: 'var(--grey-mid)' } as React.CSSProperties} />
                </div>
                <span style={{ fontSize: 13, color: 'var(--grey-mid)' }}>{item}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Anonymous source preview */}
      <div style={{ marginBottom: 28 }}>
        <p style={{ fontSize: 12, color: 'var(--grey-mid)', marginBottom: 10, letterSpacing: '0.03em' }}>
          How you will appear to journalists
        </p>
        <div style={{
          background: 'var(--charcoal)',
          borderRadius: 'var(--radius-lg)',
          padding: '18px 22px',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <div style={{
              width: 38,
              height: 38,
              borderRadius: '50%',
              background: 'rgba(255,255,255,0.1)',
              border: '1px solid rgba(255,255,255,0.15)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
              <span style={{ color: 'rgba(255,255,255,0.4)', fontSize: 16 }}>?</span>
            </div>
            <div>
              <p style={{ fontSize: 14, fontWeight: 600, color: 'white' }}>Anonymous Source</p>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 3 }}>
                <Check size={11} style={{ color: '#6ECFAD' } as React.CSSProperties} />
                <span style={{ fontSize: 12, color: '#6ECFAD', fontWeight: 500 }}>Firsthand Verified</span>
              </div>
            </div>
          </div>
          <div style={{
            padding: '6px 14px',
            background: 'rgba(104,27,43,0.4)',
            border: '1px solid rgba(104,27,43,0.6)',
            borderRadius: 'var(--radius)',
            fontSize: 12,
            fontWeight: 500,
            color: 'rgba(255,255,255,0.9)',
          }}>
            Connection verified · {credential.year}
          </div>
        </div>
      </div>

      <PrimaryButton onClick={() => onNavigate('submission-success')} fullWidth>
        Attach proof &amp; submit anonymously
      </PrimaryButton>
    </PageShell>
  )
}

// ─── Screen 7 — Submission Success ───────────────────────────────────────────

function SubmissionSuccess({
  tip,
  credential,
  submissionId,
  onNavigate,
}: {
  tip: TipData
  credential: Credential
  submissionId: string
  onNavigate: (s: Screen) => void
}) {
  const [visible, setVisible] = useState(false)
  useEffect(() => { const t = setTimeout(() => setVisible(true), 80); return () => clearTimeout(t) }, [])

  return (
    <PageShell>
      <div style={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0)' : 'translateY(12px)',
        transition: 'opacity 0.5s ease, transform 0.5s ease',
      }}>
        {/* Success icon */}
        <div style={{
          width: 52,
          height: 52,
          borderRadius: '50%',
          background: 'rgba(45,138,78,0.1)',
          border: '1px solid rgba(45,138,78,0.3)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          marginBottom: 24,
        }}>
          <Check size={22} style={{ color: '#2D8A4E' } as React.CSSProperties} />
        </div>

        <SectionHeading
          title="Your tip was submitted."
          body="Your submission has been received. Your identity was not included at any point in this process."
        />

        {/* Submission ID */}
        <Card style={{ padding: '14px 20px', marginBottom: 20, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div>
            <p style={{ fontSize: 11, color: 'var(--grey-mid)', marginBottom: 3 }}>Submission ID</p>
            <p style={{ fontSize: 13, fontFamily: 'monospace', letterSpacing: '0.06em', color: 'var(--charcoal)', fontWeight: 500 }}>
              {submissionId}
            </p>
          </div>
          <Chip accent>Anonymous</Chip>
        </Card>

        {/* Shared / not shared */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 28 }}>
          <Card style={{ padding: 20 }}>
            <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: '#2D8A4E', marginBottom: 14 }}>
              Shared with journalist
            </p>
            {[
              'Tip content',
              tip.files.length > 0 ? `Supporting evidence (${tip.files.length} file${tip.files.length > 1 ? 's' : ''})` : null,
              `Verified connection to ${credential.organization}`,
              `Employment activity · ${credential.year}`,
            ].filter(Boolean).map(item => (
              <div key={item as string} style={{ display: 'flex', alignItems: 'flex-start', gap: 8, marginBottom: 10 }}>
                <Check size={13} style={{ color: '#2D8A4E', marginTop: 2, flexShrink: 0 } as React.CSSProperties} />
                <span style={{ fontSize: 13, color: 'var(--charcoal)', lineHeight: 1.5 }}>{item}</span>
              </div>
            ))}
          </Card>
          <Card style={{ padding: 20 }}>
            <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--grey-mid)', marginBottom: 14 }}>
              Not shared
            </p>
            {['Name', 'Employment records', 'Account information', 'Any identifying information'].map(item => (
              <div key={item} style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
                <Lock size={12} style={{ color: 'var(--grey-mid)', flexShrink: 0 } as React.CSSProperties} />
                <span style={{ fontSize: 13, color: 'var(--grey-mid)' }}>{item}</span>
              </div>
            ))}
          </Card>
        </div>

        <div style={{
          padding: '14px 16px',
          background: 'var(--grey-faint)',
          border: '1px solid var(--grey-light)',
          borderRadius: 'var(--radius)',
          marginBottom: 28,
          fontSize: 13,
          color: 'var(--grey-mid)',
          lineHeight: 1.65,
        }}>
          Save your submission ID for your records. This ID can be used to reference your submission, but cannot be used to identify you.
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
          <PrimaryButton onClick={() => onNavigate('journalist-view')} fullWidth>
            View journalist experience <ArrowRight />
          </PrimaryButton>
          <GhostButton onClick={() => onNavigate('homepage')}>
            Return to homepage
          </GhostButton>
        </div>
      </div>
    </PageShell>
  )
}

// ─── Screen 8 — Journalist View ───────────────────────────────────────────────

function JournalistView({
  tip,
  credential,
  submissionId,
  onNavigate,
}: {
  tip: TipData
  credential: Credential
  submissionId: string
  onNavigate: (s: Screen) => void
}) {
  const [expanded, setExpanded] = useState(true)

  return (
    <div>
      {/* Journalist header bar */}
      <div style={{
        background: 'var(--white)',
        borderBottom: '1px solid var(--grey-light)',
        padding: '12px 48px',
      }}>
        <div style={{ maxWidth: 1200, margin: '0 auto', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 20 }}>
            {['Inbox', 'Verified Sources', 'Archive'].map((tab, i) => (
              <button
                key={tab}
                style={{
                  fontSize: 13,
                  fontWeight: i === 0 ? 600 : 400,
                  color: i === 0 ? 'var(--charcoal)' : 'var(--grey-mid)',
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  paddingBottom: 4,
                  borderBottom: i === 0 ? '2px solid var(--maroon)' : '2px solid transparent',
                }}
              >
                {tab}
                {i === 0 && (
                  <span style={{
                    marginLeft: 6,
                    fontSize: 11,
                    background: 'var(--maroon)',
                    color: 'white',
                    borderRadius: 100,
                    padding: '1px 6px',
                    fontWeight: 600,
                  }}>1</span>
                )}
              </button>
            ))}
          </div>
          <button
            onClick={() => onNavigate('homepage')}
            style={{
              fontSize: 12,
              color: 'var(--grey-mid)',
              background: 'none',
              border: '1px solid var(--grey-light)',
              borderRadius: 'var(--radius)',
              padding: '6px 14px',
              cursor: 'pointer',
            }}
          >
            ← Exit journalist view
          </button>
        </div>
      </div>

      {/* Main layout */}
      <div style={{ maxWidth: 1200, margin: '0 auto', padding: '0 48px', display: 'grid', gridTemplateColumns: '260px 1fr', gap: 24, paddingTop: 32, paddingBottom: 64 }}>

        {/* Sidebar — tip list */}
        <div>
          <p style={{ fontSize: 11, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--grey-mid)', marginBottom: 14 }}>
            Recent tips
          </p>
          <div
            style={{
              background: 'var(--white)',
              border: '1.5px solid var(--maroon)',
              borderRadius: 'var(--radius)',
              padding: '14px 16px',
              cursor: 'pointer',
            }}
          >
            <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 6 }}>
              <div style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--maroon)', flexShrink: 0 }} />
              <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--charcoal)' }}>{tip.organization}</p>
            </div>
            <p style={{ fontSize: 12, color: 'var(--grey-mid)', marginBottom: 8 }}>Anonymous Source</p>
            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <Check size={11} style={{ color: 'var(--maroon)' } as React.CSSProperties} />
              <span style={{ fontSize: 11, color: 'var(--maroon)', fontWeight: 500 }}>Firsthand Verified</span>
            </div>
            <p style={{ fontSize: 11, color: 'var(--grey-mid)', marginTop: 8 }}>
              {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
            </p>
          </div>
        </div>

        {/* Main content */}
        <div>
          {/* Tip header */}
          <div style={{ marginBottom: 24 }}>
            <div style={{ display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between', marginBottom: 6 }}>
              <h1 style={{
                fontFamily: 'Playfair Display, serif',
                fontSize: 30,
                fontWeight: 600,
                color: 'var(--charcoal)',
                letterSpacing: '-0.02em',
              }}>
                {tip.organization}
              </h1>
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 4 }}>
                <div style={{
                  width: 32,
                  height: 32,
                  borderRadius: '50%',
                  background: 'var(--grey-faint)',
                  border: '1px solid var(--grey-light)',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}>
                  <span style={{ fontSize: 12, color: 'var(--grey-mid)', fontWeight: 700 }}>?</span>
                </div>
                <div>
                  <p style={{ fontSize: 13, fontWeight: 600, color: 'var(--charcoal)' }}>Anonymous Source</p>
                  <p style={{ fontSize: 11, color: 'var(--grey-mid)' }}>{submissionId}</p>
                </div>
              </div>
            </div>
            <p style={{ fontSize: 13, color: 'var(--grey-mid)' }}>
              Received {new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })} at {new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })} UTC
            </p>
          </div>

          {/* VERIFICATION CARD — the hero element */}
          <div style={{
            background: 'var(--white)',
            border: '1.5px solid var(--maroon)',
            borderRadius: 'var(--radius-lg)',
            overflow: 'hidden',
            marginBottom: 20,
            boxShadow: '0 2px 16px rgba(104,27,43,0.10)',
          }}>
            {/* Maroon header */}
            <div style={{
              background: 'var(--maroon)',
              padding: '14px 24px',
              display: 'flex',
              alignItems: 'center',
              gap: 10,
            }}>
              <Check size={16} style={{ color: 'white' } as React.CSSProperties} />
              <span style={{
                fontSize: 13,
                fontWeight: 700,
                color: 'white',
                letterSpacing: '0.06em',
                textTransform: 'uppercase',
                fontFamily: 'Playfair Display, serif',
              }}>
                Firsthand Verified
              </span>
              <span style={{ marginLeft: 'auto', fontSize: 11, color: 'rgba(255,255,255,0.55)', fontFamily: 'monospace' }}>
                {credential.id}
              </span>
            </div>

            {/* Verification details */}
            <div style={{ padding: '20px 24px' }}>
              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 20, marginBottom: 20 }}>
                <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12, gridColumn: 'span 2' }}>
                  <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
                    {[
                      {
                        label: `Connection to ${credential.organization} verified`,
                        sub: 'Source has employer-reported evidence of a connection to this organization',
                      },
                      {
                        label: `Employment activity verified · ${credential.year}`,
                        sub: 'Active employment or engagement confirmed during this period',
                      },
                      {
                        label: 'Identity protected',
                        sub: "The source's name and documents are not accessible",
                        locked: true,
                      },
                    ].map(item => (
                      <div key={item.label} style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
                        <div style={{
                          width: 22,
                          height: 22,
                          borderRadius: '50%',
                          background: item.locked ? 'var(--grey-faint)' : 'rgba(104,27,43,0.08)',
                          border: `1px solid ${item.locked ? 'var(--grey-light)' : 'rgba(104,27,43,0.2)'}`,
                          display: 'flex',
                          alignItems: 'center',
                          justifyContent: 'center',
                          flexShrink: 0,
                          marginTop: 1,
                        }}>
                          {item.locked
                            ? <Lock size={11} style={{ color: 'var(--grey-mid)' } as React.CSSProperties} />
                            : <Check size={12} style={{ color: 'var(--maroon)' } as React.CSSProperties} />
                          }
                        </div>
                        <div>
                          <p style={{ fontSize: 14, fontWeight: item.locked ? 400 : 500, color: item.locked ? 'var(--grey-mid)' : 'var(--charcoal)' }}>
                            {item.label}
                          </p>
                          <p style={{ fontSize: 12, color: 'var(--grey-mid)', marginTop: 2 }}>{item.sub}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Status column */}
                <div style={{
                  borderLeft: '1px solid var(--grey-light)',
                  paddingLeft: 20,
                  display: 'flex',
                  flexDirection: 'column',
                  justifyContent: 'center',
                  gap: 16,
                }}>
                  {[
                    { label: 'Credential status', value: 'Valid', color: '#2D8A4E' },
                    { label: 'Non-transferable', value: 'Yes', color: 'var(--charcoal)' },
                    { label: 'Issued', value: credential.issuedAt, color: 'var(--charcoal)' },
                  ].map(item => (
                    <div key={item.label}>
                      <p style={{ fontSize: 11, color: 'var(--grey-mid)', marginBottom: 3 }}>{item.label}</p>
                      <p style={{ fontSize: 13, fontWeight: 600, color: item.color }}>{item.value}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Important disclaimer */}
              <div style={{
                borderTop: '1px solid var(--grey-light)',
                paddingTop: 16,
                display: 'flex',
                gap: 12,
              }}>
                <div style={{
                  width: 18,
                  height: 18,
                  borderRadius: '50%',
                  background: '#FEF3C7',
                  border: '1px solid #FCD34D',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  flexShrink: 0,
                  marginTop: 1,
                }}>
                  <span style={{ fontSize: 10, fontWeight: 700, color: '#92400E' }}>!</span>
                </div>
                <p style={{ fontSize: 12, color: 'var(--grey-mid)', lineHeight: 1.65 }}>
                  <strong style={{ color: 'var(--charcoal)', fontWeight: 600 }}>Firsthand verifies the source's connection to the organization, not the truth of their claims.</strong>{' '}
                  All allegations require independent journalistic investigation, corroboration, and editorial judgment before publication.
                </p>
              </div>
            </div>
          </div>

          {/* What Firsthand verifies / does not verify */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, marginBottom: 20 }}>
            <Card style={{ padding: 20 }}>
              <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: '#2D8A4E', marginBottom: 12 }}>
                What Firsthand verifies
              </p>
              <p style={{ fontSize: 13, color: 'var(--grey-mid)', lineHeight: 1.7 }}>
                Firsthand has verified that this source has employer-reported evidence connecting them to <strong style={{ color: 'var(--charcoal)', fontWeight: 500 }}>{credential.organization}</strong> during <strong style={{ color: 'var(--charcoal)', fontWeight: 500 }}>{credential.year}</strong>. The credential belongs to the same person submitting this tip.
              </p>
            </Card>
            <Card style={{ padding: 20, borderLeft: '3px solid #FCD34D' }}>
              <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: '0.06em', textTransform: 'uppercase', color: '#92400E', marginBottom: 12 }}>
                What Firsthand does not verify
              </p>
              <p style={{ fontSize: 13, color: 'var(--grey-mid)', lineHeight: 1.7 }}>
                Firsthand does not verify that the claims in this submission are true. All allegations still require independent journalistic investigation, source corroboration, and legal review.
              </p>
            </Card>
          </div>

          {/* Tip content */}
          <Card style={{ marginBottom: 16, overflow: 'hidden' }}>
            <button
              onClick={() => setExpanded(e => !e)}
              style={{
                width: '100%',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between',
                padding: '16px 20px',
                background: 'none',
                border: 'none',
                cursor: 'pointer',
                borderBottom: expanded ? '1px solid var(--grey-light)' : 'none',
              }}
            >
              <p style={{ fontSize: 12, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--grey-mid)' }}>
                Confidential tip content
              </p>
              <span style={{ fontSize: 16, color: 'var(--grey-mid)', transform: expanded ? 'none' : 'rotate(-90deg)', transition: 'transform 0.2s' }}>
                ↓
              </span>
            </button>
            {expanded && (
              <div style={{ padding: '20px 20px' }}>
                {tip.what ? (
                  <p style={{ fontSize: 14, color: 'var(--charcoal)', lineHeight: 1.75, whiteSpace: 'pre-wrap' }}>
                    {tip.what}
                  </p>
                ) : (
                  <p style={{ fontSize: 14, color: 'var(--grey-mid)', fontStyle: 'italic' }}>
                    No tip content was entered in this prototype session.
                  </p>
                )}
              </div>
            )}
          </Card>

          {/* Evidence */}
          {tip.files.length > 0 && (
            <Card style={{ padding: 20 }}>
              <p style={{ fontSize: 12, fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', color: 'var(--grey-mid)', marginBottom: 14 }}>
                Attached evidence
              </p>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {tip.files.map(f => (
                  <div
                    key={f}
                    style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: 10,
                      padding: '10px 14px',
                      background: 'var(--grey-faint)',
                      border: '1px solid var(--grey-light)',
                      borderRadius: 'var(--radius)',
                      cursor: 'pointer',
                    }}
                    onMouseEnter={e => (e.currentTarget.style.borderColor = 'var(--charcoal)')}
                    onMouseLeave={e => (e.currentTarget.style.borderColor = 'var(--grey-light)')}
                  >
                    <Paperclip size={14} style={{ color: 'var(--grey-mid)' } as React.CSSProperties} />
                    <span style={{ fontSize: 13, color: 'var(--charcoal)', flex: 1 }}>{f}</span>
                    <span style={{ fontSize: 12, color: 'var(--maroon)', fontWeight: 500 }}>Download</span>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>
      </div>
    </div>
  )
}

// ─── Root ─────────────────────────────────────────────────────────────────────

const DEFAULT_TIP: TipData = {
  organization: '',
  year: '2025',
  what: '',
  files: [],
}

function generateSubmissionId() {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'
  return 'SUB-' + Array.from({ length: 12 }, (_, i) =>
    i > 0 && i % 4 === 0 ? '-' + chars[Math.floor(Math.random() * chars.length)] : chars[Math.floor(Math.random() * chars.length)]
  ).join('')
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('homepage')
  const [tip, setTip] = useState<TipData>(DEFAULT_TIP)
  const [credential, setCredential] = useState<Credential | null>(null)
  const [submissionId] = useState(generateSubmissionId)

  const navigate = (s: Screen) => {
    window.scrollTo({ top: 0, behavior: 'instant' })
    setScreen(s)
  }

  const isJournalist = screen === 'journalist-view'

  return (
    <div style={{ minHeight: '100%', background: 'var(--bg)' }}>
      <Nav isJournalist={isJournalist} onNavigate={navigate} />

      {screen === 'homepage' && <Homepage onNavigate={navigate} />}

      {screen === 'submit-tip' && (
        <SubmitTip tip={tip} onChange={setTip} onNavigate={navigate} />
      )}

      {screen === 'verify-connection' && (
        <VerifyConnection tip={tip} onNavigate={navigate} />
      )}

      {screen === 'authorize-verification' && (
        <AuthorizeVerification
          tip={tip}
          onIssued={setCredential}
          onNavigate={navigate}
        />
      )}

      {screen === 'credential-issued' && credential && (
        <CredentialIssued credential={credential} onNavigate={navigate} />
      )}

      {screen === 'choose-proof' && credential && (
        <ChooseProof tip={tip} credential={credential} onNavigate={navigate} />
      )}

      {screen === 'submission-success' && credential && (
        <SubmissionSuccess
          tip={tip}
          credential={credential}
          submissionId={submissionId}
          onNavigate={navigate}
        />
      )}

      {screen === 'journalist-view' && credential && (
        <JournalistView
          tip={tip}
          credential={credential}
          submissionId={submissionId}
          onNavigate={navigate}
        />
      )}
    </div>
  )
}
